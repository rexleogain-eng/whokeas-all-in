-- officialwhokeas Ai v14 Supabase memory + public storage schema
-- Paste this into Supabase SQL Editor and click Run.

create table if not exists public.owai_memory_snapshots (
  id uuid primary key default gen_random_uuid(),
  owner_id text not null default 'officialwhokeas',
  app_version text not null default 'v14',
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists owai_memory_snapshots_owner_created_idx
on public.owai_memory_snapshots (owner_id, created_at desc);

alter table public.owai_memory_snapshots enable row level security;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'public'
      and tablename = 'owai_memory_snapshots'
      and policyname = 'No direct client access'
  ) then
    create policy "No direct client access"
    on public.owai_memory_snapshots
    for all
    using (false)
    with check (false);
  end if;
end $$;

-- Public bucket is needed because Instagram Content Publishing requires a publicly reachable image_url.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'owai-generated',
  'owai-generated',
  true,
  10485760,
  array['image/png','image/jpeg','image/webp']::text[]
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'storage'
      and tablename = 'objects'
      and policyname = 'Public read owai generated media'
  ) then
    create policy "Public read owai generated media"
    on storage.objects
    for select
    using (bucket_id = 'owai-generated');
  end if;
end $$;
