export type StorySlot = "morning" | "noon" | "evening" | "night";

export type GeneratedStory = {
  slot: StorySlot;
  title: string;
  subtitle: string;
  cta: string;
  theme: string;
};

export type PostingPlanItem = {
  time: string;
  label: string;
  channel: "feed" | "story" | "reel" | "carousel";
  task: string;
};

export type GrowthScore = {
  stopPower: string;
  saveReason: string;
  commentTrigger: string;
  safetyRule: string;
};

export type PsychologyTrigger = {
  principle: string;
  emotionTarget: string;
  hookFormula: string;
  whyItWorks: string;
};

export type RecognitionSystem = {
  formatName: string;
  visualFingerprint: string;
  firstLineRule: string;
  captionMove: string;
  storySequence: string;
  followerAction: string;
};

export type GeneratedPack = {
  date: string;
  isoDate: string;
  dayLabel: string;
  niche: string;
  mainTopic: string;
  hook: string;
  reelScript: string[];
  feedCard: {
    headline: string;
    subline: string;
    footer: string;
  };
  carousel: string[];
  caption: string;
  hashtags: string[];
  stories: GeneratedStory[];
  whatsappReport: string;
  palette: PaletteName;
  contentIntensity?: ContentIntensity;
  accountGoal?: AccountGoal;
  postingPlan: PostingPlanItem[];
  growthScore: GrowthScore;
  psychologyTrigger: PsychologyTrigger;
  recognitionSystem: RecognitionSystem;
};

export type PaletteName =
  "emerald" | "royal" | "sunset" | "midnight" | "gold" | "aqua";

export type ContentIntensity =
  | "normal"
  | "crazy"
  | "deep"
  | "money"
  | "study"
  | "trading";

export type AccountGoal =
  | "followers"
  | "saves"
  | "comments"
  | "dms"
  | "traffic";

type PackOptions = {
  seedShift?: number;
  intensity?: ContentIntensity;
  accountGoal?: AccountGoal;
};

type SmartPlanOptions = PackOptions & {
  avoidTopics?: string[];
};

type TopicBank = {
  name: string;
  topics: string[];
  hooks: string[];
  painLines: string[];
  quickLessons: string[];
  ctas: string[];
  hashtags: string[];
};

const psychologyTriggers: PsychologyTrigger[] = [
  {
    principle: "Curiosity gap",
    emotionTarget: "mild tension + need for closure",
    hookFormula: "You think X is the problem, but the hidden problem is Y.",
    whyItWorks:
      "It gives people a small knowledge gap, so they keep reading to close it.",
  },
  {
    principle: "Negativity bias",
    emotionTarget: "concern without hopelessness",
    hookFormula: "The quiet mistake that is costing you more than you think.",
    whyItWorks:
      "People notice threats and losses faster than neutral advice, so the post stops the scroll.",
  },
  {
    principle: "High-arousal emotion",
    emotionTarget: "awe, urgency, controlled anger, anxiety-to-action",
    hookFormula:
      "This feels uncomfortable, but it explains why most people stay stuck.",
    whyItWorks:
      "High-arousal emotions increase sharing more than low-arousal emotions.",
  },
  {
    principle: "Von Restorff / pattern interrupt",
    emotionTarget: "surprise + attention reset",
    hookFormula:
      "Say the opposite of common advice, then explain the useful truth.",
    whyItWorks:
      "Distinctive items stand out inside a feed full of repeated motivational content.",
  },
  {
    principle: "Social currency",
    emotionTarget: "identity + status",
    hookFormula: "Smart people notice this before everyone else does.",
    whyItWorks:
      "People share content that makes them look aware, disciplined, or helpful.",
  },
  {
    principle: "Practical value",
    emotionTarget: "relief + immediate usefulness",
    hookFormula: "Do this one small thing today to fix X.",
    whyItWorks:
      "Useful content gives people a reason to save and revisit the post.",
  },
];

const banks: Record<string, TopicBank> = {
  psychomix: {
    name: "Psychology Growth Engine",
    topics: [
      "YOUR BRAIN IS NOT TIRED IT IS OVERSTIMULATED",
      "THIS IS WHY YOU KEEP STARTING AND STOPPING",
      "THE APP ON YOUR PHONE IS TRAINING YOUR MOOD",
      "YOU ARE NOT LAZY YOU ARE REWARDED FOR DISTRACTION",
      "MOST PEOPLE DO NOT NEED MOTIVATION THEY NEED FRICTION",
      "THE COMFORT LOOP THAT MAKES YEARS DISAPPEAR",
      "YOUR ATTENTION IS BEING SPENT BEFORE YOU WAKE UP",
      "THIS TINY HABIT IS STEALING YOUR FUTURE QUIETLY",
      "THE SCARIEST PART IS YOU THINK THIS IS NORMAL",
      "YOUR BRAIN BELIEVES WHAT YOU REPEAT NOT WHAT YOU WANT",
      "THE REAL REASON YOU KEEP PROCRASTINATING",
      "STOP TRUSTING YOUR MOOD TO MAKE BIG DECISIONS",
      "IF YOU NEED MOTIVATION DAILY YOUR SYSTEM IS BROKEN",
      "THE DAY IS WON BEFORE THE PHONE WINS",
      "YOUR LIFE CHANGES WHEN BORING BECOMES NORMAL",
    ],
    hooks: [
      "This will make some people uncomfortable because it is too accurate.",
      "You are not behind because of one mistake. You are behind because of repeated loops.",
      "Your brain is choosing the easiest reward, not the best future.",
      "The problem is not that you have no time. The problem is what owns your attention.",
      "Read this slowly if you feel like your life is moving but not improving.",
      "Nobody talks about this because it looks normal from outside.",
      "The habit does not feel dangerous until you count how many days it has stolen.",
    ],
    painLines: [
      "Easy rewards teach your mind to avoid anything that needs patience.",
      "You keep waiting to feel ready, but readiness usually comes after action.",
      "Scrolling feels harmless because the cost is paid slowly, not immediately.",
      "Your mood changes fast because your attention is being pulled in too many directions.",
      "Most people do not fail loudly. They disappear quietly into routine.",
      "The brain repeats what feels familiar, even when familiar is destroying progress.",
      "Your future is not blocked by lack of talent. It is blocked by repeated distraction.",
    ],
    quickLessons: [
      "Put one useful action before the first scroll.",
      "Make the bad habit harder and the good habit easier.",
      "Use a 10-minute start rule before your brain negotiates.",
      "Remove one trigger instead of depending on willpower.",
      "Track the habit for 7 days and let the pattern embarrass you into change.",
      "Choose one boring action and repeat it until it becomes proof.",
      "Delay the easy reward until after the useful task.",
    ],
    ctas: [
      "Save this before your brain pretends it never saw it.",
      "Comment LOOP if this explains you.",
      "Send this to someone who keeps saying tomorrow.",
      "Reply RESET if you are taking your attention back.",
      "Share this with a person who needs a clean restart.",
      "Follow for uncomfortable truths that actually help.",
    ],
    hashtags: [
      "#psychology",
      "#humanbehavior",
      "#mindsetshift",
      "#dopamine",
      "#discipline",
      "#selfimprovement",
      "#focus",
      "#facelesspage",
      "#growth",
    ],
  },
  curiosity: {
    name: "Curiosity Hooks",
    topics: [
      "THE THING YOU IGNORE IS PROBABLY CONTROLLING YOU",
      "ONE QUESTION THAT EXPOSES YOUR REAL PRIORITIES",
      "WHY YOUR BRAIN LOVES BAD HABITS MORE THAN GOOD ONES",
      "THE REASON YOU FEEL BUSY BUT EMPTY",
      "THE SMALL DETAIL THAT CHANGES HOW PEOPLE SEE YOU",
      "WHY YOU CAN KNOW THE ANSWER AND STILL NOT MOVE",
      "THE HIDDEN PRICE OF BEING ALWAYS AVAILABLE",
      "WHAT YOUR FIRST HOUR SAYS ABOUT YOUR FUTURE",
      "THE REASON YOUR PLAN FAILS BY 10 AM",
      "WHY SILENCE MAKES SOME PEOPLE UNCOMFORTABLE",
    ],
    hooks: [
      "There is a reason this keeps happening, and it is not random.",
      "Once you see this pattern, you cannot unsee it.",
      "Most people solve the wrong problem first.",
      "The answer is boring, but that is why it works.",
      "This sounds small until you watch it repeat for one month.",
    ],
    painLines: [
      "You do not lack information. You lack a trigger that forces action.",
      "The brain avoids unclear tasks, then calls it laziness.",
      "If everything can interrupt you, nothing can grow deeply.",
      "You keep adding goals while protecting the habits that destroy them.",
    ],
    quickLessons: [
      "Ask: what am I avoiding because it feels unclear?",
      "Turn the task into the first tiny visible step.",
      "Protect one block of attention every day.",
      "Write the one action that would make today count.",
    ],
    ctas: [
      "Save this question.",
      "Comment HONEST if it hit you.",
      "Share this with someone who needs clarity.",
      "Follow for brain-level growth.",
    ],
    hashtags: [
      "#curiosity",
      "#mindset",
      "#psychologyfacts",
      "#productivity",
      "#selfawareness",
      "#focus",
      "#growthmindset",
      "#facelesscontent",
    ],
  },
  moneypsych: {
    name: "Money Psychology",
    topics: [
      "LOOKING SUCCESSFUL CAN KEEP YOU BROKE",
      "YOUR EGO IS MORE EXPENSIVE THAN YOUR BILLS",
      "THE FIRST MONEY SKILL IS DELAYING IMPULSE",
      "WHY SMALL MONEY DISAPPEARS FAST",
      "BROKE IS OFTEN A BEHAVIOR BEFORE IT IS A BALANCE",
      "THE INTERNET SELLS LIFESTYLE NOT FREEDOM",
      "STOP BUYING RESPECT FROM PEOPLE WHO ARE NOT PAYING YOU",
      "SKILLS MAKE MONEY WHEN MOOD DISAPPEARS",
      "THE QUIET HABIT THAT BUILDS FINANCIAL OPTIONS",
      "FAST MONEY STORIES HIDE SLOW DISCIPLINE",
    ],
    hooks: [
      "This money truth hurts because it exposes the ego.",
      "Most people are not broke from one big mistake. They are leaking money daily.",
      "The rich-looking habit is often the broke-making habit.",
      "Money does not respect excitement. It respects repeated control.",
      "If small money disappears, big money will expose the same pattern.",
    ],
    painLines: [
      "Many people spend to be seen by people who will not save them.",
      "Impulse buying gives quick identity but removes future options.",
      "A skill can keep paying after motivation has left.",
      "The need to impress is one of the most expensive emotions.",
    ],
    quickLessons: [
      "Delay one purchase for 24 hours.",
      "Build one monetizable skill before buying status.",
      "Track the small leaks for 7 days.",
      "Spend less on appearing and more on becoming.",
    ],
    ctas: [
      "Save this money truth.",
      "Comment EGO if this is real.",
      "Send this before someone wastes money.",
      "Follow for money psychology.",
    ],
    hashtags: [
      "#moneymindset",
      "#moneypsychology",
      "#wealthbuilding",
      "#financialdiscipline",
      "#skillsfirst",
      "#selfcontrol",
      "#facelesspage",
      "#buildquietly",
    ],
  },
  socialtruth: {
    name: "Social Truths",
    topics: [
      "PEOPLE DO NOT RESPECT POTENTIAL THEY RESPECT PROOF",
      "STOP EXPLAINING YOURSELF TO PEOPLE WHO BENEFIT FROM CONFUSION",
      "YOUR CIRCLE NORMALIZES YOUR LIMITS",
      "SILENCE REVEALS WHO NEEDS ACCESS TO YOU",
      "THE WRONG PEOPLE MAKE DISCIPLINE LOOK WEIRD",
      "ATTENTION IS THE NEW RESPECT AND MOST PEOPLE WASTE IT",
      "SOME PEOPLE ONLY SUPPORT YOU WHEN YOU STAY SMALL",
      "PRIVATE WORK LOOKS BORING UNTIL RESULTS ARRIVE",
      "CONFIDENCE WITHOUT PROOF BECOMES NOISE",
      "THE PEOPLE AROUND YOU TRAIN YOUR STANDARD",
    ],
    hooks: [
      "This is not about hating people. It is about seeing patterns clearly.",
      "Some environments do not destroy you loudly. They lower your standard quietly.",
      "The people around you can make growth feel abnormal.",
      "A quiet person with proof is louder than a loud person with promises.",
      "Not everyone who claps for you wants you to outgrow them.",
    ],
    painLines: [
      "If your circle laughs at discipline, your future has to fight your environment too.",
      "Explaining yourself to the wrong people drains the energy needed to build.",
      "People respect repeated evidence more than repeated announcements.",
      "You can love people and still stop letting them manage your attention.",
    ],
    quickLessons: [
      "Share less. Build more.",
      "Let results explain what words cannot.",
      "Protect your standard even when people call it boring.",
      "Choose one person who makes you want to improve, not perform.",
    ],
    ctas: [
      "Save this social truth.",
      "Comment PROOF if you understand.",
      "Share with someone building quietly.",
      "Follow for sharp daily truths.",
    ],
    hashtags: [
      "#socialtruth",
      "#selfrespect",
      "#growthmindset",
      "#mindset",
      "#discipline",
      "#boundaries",
      "#facelesscontent",
      "#successhabits",
    ],
  },
  ai: {
    name: "AI Curiosity",
    topics: [
      "AI WILL NOT REPLACE YOU BUT PEOPLE USING SYSTEMS WILL",
      "STOP USING AI LIKE A SEARCH BOX",
      "THE BEST PROMPT IS NOT A QUESTION IT IS A JOB DESCRIPTION",
      "AI MULTIPLIES CLARITY NOT CONFUSION",
      "ONE IDEA CAN BECOME A WEEK OF CONTENT",
      "THE PEOPLE WINNING WITH AI ARE BUILDING WORKFLOWS",
      "YOUR PROMPTS FAIL BECAUSE YOUR OUTPUT IS UNCLEAR",
      "AI IS NOT MAGIC IT IS LEVERAGE",
      "MOST PEOPLE PLAY WITH AI INSTEAD OF EMPLOYING IT",
      "THE FUTURE REWARDS SYSTEM THINKERS",
    ],
    hooks: [
      "AI is not the advantage. Your workflow is the advantage.",
      "This is why two people use the same AI and get completely different results.",
      "Random prompts create random outcomes.",
      "Use AI like a worker with a job, not a toy with guesses.",
      "The future belongs to people who can turn ideas into systems.",
    ],
    painLines: [
      "Most people ask AI for answers instead of giving it a repeatable job.",
      "If you do not define the output, AI will fill the gap with generic content.",
      "The person with a system can produce daily while others keep planning.",
      "AI saves time only when your process is clear.",
    ],
    quickLessons: [
      "Give AI the role, audience, task, format, and examples.",
      "Save prompts that produce good results and reuse them.",
      "Turn one idea into a feed post, story set, caption, and script.",
      "Build a workflow before chasing another tool.",
    ],
    ctas: [
      "Save this AI rule.",
      "Comment SYSTEM if you get it.",
      "Share with a beginner using AI wrongly.",
      "Follow for simple AI workflows.",
    ],
    hashtags: [
      "#aitools",
      "#chatgpt",
      "#aiautomation",
      "#contentcreation",
      "#facelesscontent",
      "#productivity",
      "#systems",
      "#digitaltools",
    ],
  },
  study: {
    name: "Study Psychology",
    topics: [
      "READING IS NOT STUDYING",
      "YOUR BRAIN LIKES FAMILIAR NOTES NOT HARD RECALL",
      "WHY YOU FORGET AFTER REVISION",
      "THE STUDY METHOD THAT FEELS BAD BECAUSE IT WORKS",
      "STOP HIGHLIGHTING EVERYTHING",
      "EXAM PANIC STARTS DURING WEAK REVISION",
      "QUESTIONS EXPOSE WHAT READING HIDES",
      "SLEEP IS PART OF MEMORY NOT A BREAK FROM STUDY",
      "THE BRAIN REMEMBERS WHAT IT STRUGGLES TO RETRIEVE",
      "RECOGNITION IS NOT RECALL",
    ],
    hooks: [
      "This is why you feel ready while studying and blank inside the exam.",
      "Your brain lies when notes look familiar.",
      "The study method that feels uncomfortable is usually the one working.",
      "If revision never tests you, the exam will.",
      "Highlighting feels productive because it is easy, not because it is enough.",
    ],
    painLines: [
      "Passive reading builds recognition, but exams demand recall.",
      "You forget because you never forced the brain to retrieve the answer without help.",
      "Many students revise what feels comfortable and avoid what would expose them.",
      "Questions hurt now so the exam hurts less later.",
    ],
    quickLessons: [
      "Close the notes and explain from memory.",
      "Use questions before rereading.",
      "Revise weak topics first.",
      "Teach the topic like you are explaining to a beginner.",
    ],
    ctas: [
      "Save this study rule.",
      "Comment RECALL if you needed this.",
      "Share with a student.",
      "Follow for study psychology.",
    ],
    hashtags: [
      "#studytips",
      "#activeRecall",
      "#studentlife",
      "#examprep",
      "#revision",
      "#learning",
      "#studymotivation",
      "#facelesspage",
    ],
  },
  trading: {
    name: "Trading Psychology",
    topics: [
      "REVENGE TRADING IS EMOTION WEARING A SUIT",
      "THE MARKET PUNISHES IMPATIENCE FAST",
      "ONE BAD TRADE SHOULD NOT BECOME A BAD DAY",
      "RISK MANAGEMENT IS THE REAL STRATEGY",
      "A SETUP IS NOT A FEELING",
      "YOUR JOURNAL KNOWS WHAT YOUR EGO DENIES",
      "PATIENCE IS A POSITION",
      "STOP CHASING EVERY CANDLE",
      "OVERCONFIDENCE IS EXPENSIVE",
      "TRADE LESS REVIEW MORE",
    ],
    hooks: [
      "The market does not need to hate you for you to lose money.",
      "Most traders do not lose from analysis. They lose from behavior.",
      "A good setup cannot save bad risk control.",
      "The chart moves. Your emotions should not drive the account.",
      "Trading exposes discipline faster than most people can handle.",
    ],
    painLines: [
      "Revenge trading turns one loss into a full account problem.",
      "Without rules, every trade becomes a mood decision.",
      "Chasing candles usually means entering after patience has already failed.",
      "Your journal shows patterns your memory edits.",
    ],
    quickLessons: [
      "Set risk before entry.",
      "Do not trade to recover emotions.",
      "Wait for your setup or stay out.",
      "Review more than you click buy or sell.",
    ],
    ctas: [
      "Save this trading rule.",
      "Comment RISK if you understand.",
      "Share with a beginner trader.",
      "Follow for trading discipline.",
    ],
    hashtags: [
      "#tradingpsychology",
      "#forexeducation",
      "#riskmanagement",
      "#tradingtips",
      "#forextrader",
      "#discipline",
      "#tradingmindset",
      "#facelesscontent",
    ],
  },
};

const palettes: Record<
  PaletteName,
  {
    bg1: string;
    bg2: string;
    bg3: string;
    glow: string;
    accent: string;
    accent2: string;
    text: string;
    sub: string;
  }
> = {
  emerald: {
    bg1: "#f2eadc",
    bg2: "#d6c7a9",
    bg3: "#0f2f28",
    glow: "#2f6f56",
    accent: "#23483d",
    accent2: "#b85c38",
    text: "#1c1a17",
    sub: "#4d463d",
  },
  royal: {
    bg1: "#eee7dc",
    bg2: "#c7cad7",
    bg3: "#1f2a44",
    glow: "#38466c",
    accent: "#25365f",
    accent2: "#9b5d38",
    text: "#191b24",
    sub: "#42485c",
  },
  sunset: {
    bg1: "#f3dfc8",
    bg2: "#d49b73",
    bg3: "#44251d",
    glow: "#a34f31",
    accent: "#6f2f22",
    accent2: "#d68b54",
    text: "#24150f",
    sub: "#5b382a",
  },
  midnight: {
    bg1: "#e9e3d5",
    bg2: "#a8a198",
    bg3: "#1d1d1b",
    glow: "#2b2b28",
    accent: "#111111",
    accent2: "#8c6f4f",
    text: "#151515",
    sub: "#4b4843",
  },
  gold: {
    bg1: "#f4ead1",
    bg2: "#d0ad69",
    bg3: "#3d2b11",
    glow: "#9b742d",
    accent: "#5f4318",
    accent2: "#a35d22",
    text: "#211705",
    sub: "#5d4a22",
  },
  aqua: {
    bg1: "#e8eee9",
    bg2: "#a8c6bd",
    bg3: "#123432",
    glow: "#2f6b65",
    accent: "#1c4b47",
    accent2: "#b35b3e",
    text: "#14201e",
    sub: "#405551",
  },
};

const paletteNames = Object.keys(palettes) as PaletteName[];

function pick<T>(arr: T[], seed: number): T {
  return arr[Math.abs(seed) % arr.length];
}

function seedFromDate(date: Date) {
  return Number(`${date.getFullYear()}${date.getMonth() + 1}${date.getDate()}`);
}

function dateFromOffset(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d;
}

function formatDate(date: Date) {
  return date.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function isoDate(date: Date) {
  return date.toISOString().slice(0, 10);
}

function dayLabel(date: Date) {
  return date.toLocaleDateString("en-GB", { weekday: "long" });
}

function getBank(niche = "psychomix", offsetDays = 0) {
  const key = niche.toLowerCase().trim();

  if (
    [
      "growth",
      "growth-mix",
      "mixed",
      "mix",
      "viral",
      "psychomix",
      "psycho",
      "psychology-growth",
    ].includes(key)
  ) {
    const rhythm = [
      "psychomix",
      "curiosity",
      "moneypsych",
      "psychomix",
      "socialtruth",
      "ai",
      "psychomix",
      "study",
      "psychomix",
      "moneypsych",
      "socialtruth",
      "trading",
      "curiosity",
      "psychomix",
    ];
    return banks[rhythm[Math.abs(offsetDays) % rhythm.length]];
  }

  return banks[key] || banks.psychomix;
}

function feedLabel(trigger: PsychologyTrigger, seed: number) {
  const labels = [
    "UNCOMFORTABLE TRUTH",
    "YOUR BRAIN NEEDS THIS",
    "STOP AND READ",
    "PSYCHOLOGY CHECK",
    "PATTERN INTERRUPT",
    "SAVE THIS",
    trigger.principle.toUpperCase(),
  ];
  return pick(labels, seed);
}


const intensityProfiles: Record<
  ContentIntensity,
  { label: string; line: string; footer: string }
> = {
  normal: {
    label: "Normal",
    line: "Simple truth. Clear action. No fake pressure.",
    footer: "Save it if it is useful.",
  },
  crazy: {
    label: "Crazy Attention",
    line: "This hook is built to stop the scroll fast, but the lesson stays honest.",
    footer: "Do not ignore this twice.",
  },
  deep: {
    label: "Deep Psychology",
    line: "This works because it exposes a hidden behavior pattern, not just motivation.",
    footer: "Save this before the pattern repeats.",
  },
  money: {
    label: "Money Hooks",
    line: "Money content works best when it hits ego, impulse, status, and control.",
    footer: "Share this with someone wasting money silently.",
  },
  study: {
    label: "Study Hooks",
    line: "Study content should expose false confidence and push active recall.",
    footer: "Send this to a student before exams.",
  },
  trading: {
    label: "Trading Psychology",
    line: "Trading content should attack impatience, revenge trades, and poor risk control.",
    footer: "Save this before your next trade.",
  },
};

const goalProfiles: Record<AccountGoal, { label: string; cta: string; focus: string }> = {
  followers: {
    label: "Followers",
    cta: "Follow if you want daily truths that feel uncomfortable but useful.",
    focus: "broad relatability + clear identity",
  },
  saves: {
    label: "Saves",
    cta: "Save this for the next time your brain tries to negotiate.",
    focus: "practical value + repeat usefulness",
  },
  comments: {
    label: "Comments",
    cta: "Comment ONE WORD that explains what this made you notice.",
    focus: "identity question + low-effort reply",
  },
  dms: {
    label: "DMs",
    cta: "DM RESET if you want the simple checklist version.",
    focus: "private response + helpful next step",
  },
  traffic: {
    label: "Traffic",
    cta: "Check the link/profile if you want the full system behind this.",
    focus: "profile visit + next action",
  },
};

function cleanTopic(topic: string) {
  return topic.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

const recognitionFormats: RecognitionSystem[] = [
  {
    formatName: "The Quiet Truth Frame",
    visualFingerprint:
      "Cream paper background, black editorial headline, small gold underline, numbered top corner, officialwhokeas Ai footer stamp.",
    firstLineRule:
      "Start with a direct uncomfortable statement, not a greeting or brand intro.",
    captionMove:
      "Use: hook → painful truth → short psychology explanation → one action → one low-effort CTA.",
    storySequence:
      "Morning warning, noon self-check, evening proof, night reset. Same rhythm every day so followers recognize the account.",
    followerAction:
      "Ask for save/share/reply only when the post gives real practical value.",
  },
  {
    formatName: "The Pattern Breaker",
    visualFingerprint:
      "Minimal editorial card with one large headline, one human-sounding sentence, and a small imperfect stamp mark.",
    firstLineRule:
      "Open by challenging common advice: 'Motivation is not the problem...' then reveal the hidden pattern.",
    captionMove:
      "Make people feel seen, then give a clean 1-step correction they can try today.",
    storySequence:
      "Use a question story before the feed post and a reflection story after it to increase recognition and replies.",
    followerAction:
      "Invite comments using one-word answers like LOOP, RESET, FOCUS, or HONEST.",
  },
  {
    formatName: "The Save Bait Note",
    visualFingerprint:
      "Classic note-card feel: quiet colors, strong typography, no fake luxury, no neon, no clutter.",
    firstLineRule:
      "Make the first line sound like advice someone would screenshot and send to a friend.",
    captionMove:
      "Turn the headline into a micro-lesson with 3 short paragraphs and a final action.",
    storySequence:
      "Tease the topic in the morning, publish the main card in the evening, then use night story as the emotional close.",
    followerAction:
      "Tell people exactly why to save: 'Save this for the moment your brain starts negotiating.'",
  },
];

function recognitionFor(seed: number): RecognitionSystem {
  return recognitionFormats[Math.abs(seed) % recognitionFormats.length];
}

export function generateDailyPack(
  niche = "psychomix",
  offsetDays = 0,
  options: PackOptions = {},
): GeneratedPack {
  const dateObj = dateFromOffset(offsetDays);
  const seed = seedFromDate(dateObj) + offsetDays * 37 + (options.seedShift || 0) * 113;
  const bank = getBank(niche, offsetDays);
  const trigger = pick(psychologyTriggers, seed + 31);
  const mainTopic = pick(bank.topics, seed + 1);
  const hook = pick(bank.hooks, seed + 2);
  const pain = pick(bank.painLines, seed + 4);
  const lesson = pick(bank.quickLessons, seed + 5);
  const cta = pick(bank.ctas, seed + 6);
  const palette = pick(paletteNames, seed + 3);
  const label = feedLabel(trigger, seed + 44);
  const intensity = options.intensity || "deep";
  const accountGoal = options.accountGoal || "saves";
  const intensityProfile = intensityProfiles[intensity] || intensityProfiles.deep;
  const goalProfile = goalProfiles[accountGoal] || goalProfiles.saves;
  const recognitionSystem = recognitionFor(seed + 77);

  const reelScript = [
    `0-2s Hook: ${mainTopic}`,
    `2-5s Pattern interrupt: ${hook}`,
    `5-10s Pain: ${pain}`,
    `10-16s Psychology: ${trigger.principle} — ${trigger.whyItWorks}`,
    `16-21s Intensity angle: ${intensityProfile.line}`,
    `21-26s Simple action: ${lesson}`,
    `26-30s Close: ${goalProfile.cta}`,
  ];

  const feedCard = {
    headline: mainTopic,
    subline: `${hook} ${pain}`,
    footer: `${cta} ${intensityProfile.footer}`,
  };

  const carousel = [
    `Slide 1: ${mainTopic}`,
    `Slide 2: ${hook}`,
    `Slide 3: The hidden pattern: ${pain}`,
    `Slide 4: Why it catches people: ${trigger.principle}`,
    `Slide 5: Do this today: ${lesson}`,
    `Slide 6: ${goalProfile.cta}`,
  ];

  const caption = `${mainTopic}

${hook}

${pain}

The psychology behind it: ${trigger.principle}. ${trigger.whyItWorks}

Do this today: ${lesson}

Content angle: ${intensityProfile.line}
Goal: ${goalProfile.focus}

${goalProfile.cta}`;

  const stories: GeneratedStory[] = [
    {
      slot: "morning",
      title: pick(
        [
          "DON'T LET THE PHONE WIN",
          "YOUR FIRST HOUR MATTERS",
          "MORNING PSYCHOLOGY",
          "WAKE UP CHECK",
        ],
        seed + 7,
      ),
      subtitle: pick(
        [
          "Your brain follows the first reward you give it.",
          "Start with proof, not scrolling.",
          "One useful action before noise.",
          "Win attention before the feed takes it.",
        ],
        seed + 8,
      ),
      cta: pick(
        [
          "Reply READY if you are locked in.",
          "Choose one task now.",
          "Screenshot this before you forget.",
          "Start before your mood votes.",
        ],
        seed + 9,
      ),
      theme: "morning",
    },
    {
      slot: "noon",
      title: pick(
        ["BE HONEST", "MIDDAY TEST", "QUICK RESET", "ARE YOU DRIFTING?"],
        seed + 10,
      ),
      subtitle: pick(
        [
          "Did you move or just stay busy?",
          "Your focus is either protected or stolen.",
          "Half the day is enough to recover.",
          "A distracted day can still be rescued.",
        ],
        seed + 11,
      ),
      cta: pick(
        [
          "Reply YES if you are back.",
          "Do one useful thing in 10 minutes.",
          "Send this to someone distracted.",
          "Pick the task you keep avoiding.",
        ],
        seed + 12,
      ),
      theme: "noon",
    },
    {
      slot: "evening",
      title: pick(
        [
          "WHAT DID TODAY TEACH YOU?",
          "EVENING PROOF",
          "SAVE THE PATTERN",
          "DAILY TRUTH",
        ],
        seed + 13,
      ),
      subtitle: pick(
        [
          "Progress leaves evidence.",
          "Review the habit before repeating it.",
          "One lesson today prevents one mistake tomorrow.",
          "Your day exposed your real system.",
        ],
        seed + 14,
      ),
      cta: pick(
        [
          "Write one lesson.",
          "Prepare tomorrow tonight.",
          "Reply DONE if you improved one thing.",
          "Save this if it hit you.",
        ],
        seed + 15,
      ),
      theme: "evening",
    },
    {
      slot: "night",
      title: pick(
        [
          "BEFORE YOU SLEEP",
          "TOMORROW STARTS NOW",
          "NIGHT RESET",
          "DON'T END EMPTY",
        ],
        seed + 16,
      ),
      subtitle: pick(
        [
          "Your brain needs a clear next step.",
          "Rest with a plan, not regret.",
          "Close the loop before tomorrow starts.",
          "Sleep is easier when your mind has direction.",
        ],
        seed + 17,
      ),
      cta: pick(
        [
          "Set one goal for tomorrow.",
          "Screenshot for morning.",
          "Rest. Then rebuild.",
          "Decide before the day begins.",
        ],
        seed + 18,
      ),
      theme: "night",
    },
  ];

  const date = formatDate(dateObj);
  const postingPlan: PostingPlanItem[] = [
    {
      time: "07:00",
      label: "Morning Story",
      channel: "story",
      task: `${stories[0].title} — ${stories[0].cta}`,
    },
    {
      time: "12:30",
      label: "Noon Story",
      channel: "story",
      task: `${stories[1].title} — use as reply bait`,
    },
    {
      time: "18:30",
      label: "Main Feed Post",
      channel: "feed",
      task: `${label}: ${feedCard.headline} — ${intensityProfile.label} / ${goalProfile.label}`,
    },
    {
      time: "20:30",
      label: "Engagement Story",
      channel: "story",
      task: `${stories[2].title} — ask for replies/saves`,
    },
    {
      time: "22:30",
      label: "Night Story",
      channel: "story",
      task: `${stories[3].title} — tomorrow reset`,
    },
  ];

  const growthScore: GrowthScore = {
    stopPower:
      trigger.principle.includes("High") ||
      trigger.principle.includes("Negativity")
        ? "Very High"
        : "High",
    saveReason: `${trigger.principle} + practical action: ${lesson} + goal focus: ${goalProfile.focus}`,
    commentTrigger: goalProfile.cta,
    safetyRule:
      "Strong hooks, but no fake facts, fake results, hate, stolen posts, or harmful fearbait",
  };

  const reportLines = stories
    .map((s) => `✅ ${s.slot} story: ${s.title}`)
    .join("\n");
  const scheduleLines = postingPlan
    .map((p) => `${p.time} - ${p.label}: ${p.task}`)
    .join("\n");

  const whatsappReport = `📊 Daily Psychology Growth Report\nDate: ${date}\nStyle: Faceless viral psychology page\nNiche: ${bank.name}\n\n✅ 1 psychology feed card generated\n✅ 1 Reel script generated\n✅ 1 carousel generated\n${reportLines}\n\nMain hook: ${hook}\nTopic: ${mainTopic}\nPsychology trigger: ${trigger.principle}\nEmotion target: ${trigger.emotionTarget}\nContent intensity: ${intensityProfile.label}\nAccount goal: ${goalProfile.label}\n\nPosting schedule:\n${scheduleLines}\n\nGrowth logic: ${trigger.whyItWorks}\nRecognition format: ${recognitionSystem.formatName}\nVisual fingerprint: ${recognitionSystem.visualFingerprint}\nPosting rhythm: ${recognitionSystem.storySequence}\n\nNext action: Publish feed + stories. When Instagram API is connected, this can publish automatically.`;

  return {
    date,
    isoDate: isoDate(dateObj),
    dayLabel: dayLabel(dateObj),
    niche: bank.name,
    mainTopic,
    hook,
    reelScript,
    feedCard,
    carousel,
    caption,
    hashtags: bank.hashtags,
    stories,
    whatsappReport,
    palette,
    contentIntensity: intensity,
    accountGoal,
    postingPlan,
    growthScore,
    psychologyTrigger: trigger,
    recognitionSystem,
  };
}

export function generateWeekPlan(
  niche = "psychomix",
  days = 7,
  options: PackOptions = {},
) {
  return generateSmartPlan(niche, days, options);
}

export function generateSmartPlan(
  niche = "psychomix",
  days = 7,
  options: SmartPlanOptions = {},
) {
  const avoid = new Set((options.avoidTopics || []).map(cleanTopic).filter(Boolean));
  const packs: GeneratedPack[] = [];

  for (let i = 0; i < days; i++) {
    let attempt = 0;
    let candidate = generateDailyPack(niche, i, { ...options, seedShift: attempt });

    while (
      attempt < 18 &&
      (avoid.has(cleanTopic(candidate.mainTopic)) ||
        packs.some((p) => cleanTopic(p.mainTopic) === cleanTopic(candidate.mainTopic)))
    ) {
      attempt += 1;
      candidate = generateDailyPack(niche, i, { ...options, seedShift: attempt });
    }

    packs.push(candidate);
    avoid.add(cleanTopic(candidate.mainTopic));
  }

  return packs;
}

export function cardSvg(
  title: string,
  subtitle: string,
  footer: string,
  kind: "feed" | "story" = "feed",
  paletteName: PaletteName = "emerald",
) {
  const width = 1080;
  const height = kind === "story" ? 1920 : 1350;
  const p = palettes[paletteName] || palettes.emerald;

  const wrapWords = (input: string, maxChars: number, maxLines: number) => {
    const words = input.replace(/\s+/g, " ").trim().split(" ").filter(Boolean);
    const lines: string[] = [];
    let current = "";

    for (const word of words) {
      const next = current ? `${current} ${word}` : word;
      if (next.length > maxChars && current) {
        lines.push(current);
        current = word;
      } else {
        current = next;
      }
    }

    if (current) lines.push(current);
    return lines.slice(0, maxLines);
  };

  const textBlock = (
    input: string,
    x: number,
    y: number,
    maxChars: number,
    maxLines: number,
    fontSize: number,
    lineHeight: number,
    color: string,
    weight = 800,
    letterSpacing = 0,
    family = "Georgia, 'Times New Roman', serif",
  ) => {
    const lines = wrapWords(
      input.replace(/\s+/g, " ").trim(),
      maxChars,
      maxLines,
    );
    return `<text fill="${color}" font-size="${fontSize}" font-weight="${weight}" font-family="${family}" letter-spacing="${letterSpacing}">${lines
      .map(
        (line, index) =>
          `<tspan x="${x}" y="${y + index * lineHeight}">${escapeXml(line)}</tspan>`,
      )
      .join("")}</text>`;
  };

  const titleY = kind === "story" ? 540 : 330;
  const titleSize = kind === "story" ? 86 : 76;
  const titleLine = kind === "story" ? 100 : 86;
  const titleMaxChars = kind === "story" ? 15 : 17;
  const titleMaxLines = kind === "story" ? 6 : 6;
  const subtitleY = kind === "story" ? 1120 : 790;
  const subtitleSize = kind === "story" ? 45 : 38;
  const subtitleLine = kind === "story" ? 60 : 52;
  const subtitleMaxChars = kind === "story" ? 26 : 33;
  const label = kind === "story" ? "DAILY NOTE" : "EDITORIAL NOTE";
  const mini = kind === "story" ? "save • reply • share" : "save it if it found you";
  const edition = String((title.length + subtitle.length) % 9 + 1).padStart(2, "0");
  const topBandY = kind === "story" ? 250 : 215;

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" fill="none" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="paper" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="${p.bg1}"/>
      <stop offset="0.62" stop-color="${p.bg2}"/>
      <stop offset="1" stop-color="${p.bg1}"/>
    </linearGradient>
    <pattern id="finegrid" width="36" height="36" patternUnits="userSpaceOnUse">
      <path d="M36 0H0V36" stroke="${p.text}" stroke-width="0.8" opacity="0.035"/>
    </pattern>
  </defs>
  <rect width="${width}" height="${height}" fill="url(#paper)"/>
  <rect width="${width}" height="${height}" fill="url(#finegrid)"/>
  <rect x="48" y="48" width="${width - 96}" height="${height - 96}" rx="42" fill="none" stroke="${p.text}" stroke-opacity="0.42" stroke-width="3"/>
  <rect x="78" y="78" width="${width - 156}" height="${height - 156}" rx="28" fill="#ffffff" opacity="0.18" stroke="${p.text}" stroke-opacity="0.13" stroke-width="2"/>

  <rect x="92" y="102" width="${kind === "story" ? 330 : 300}" height="64" rx="32" fill="${p.text}" opacity="0.94"/>
  <text x="120" y="144" fill="${p.bg1}" font-size="27" font-weight="900" font-family="Arial, sans-serif" letter-spacing="1.8">${label}</text>
  <text x="${width - 210}" y="150" fill="${p.text}" fill-opacity="0.56" font-size="42" font-weight="900" font-family="Georgia, 'Times New Roman', serif">${edition}</text>
  <line x1="92" y1="${topBandY}" x2="${width - 92}" y2="${topBandY}" stroke="${p.text}" stroke-opacity="0.22" stroke-width="3"/>
  <circle cx="${width - 112}" cy="${topBandY}" r="9" fill="${p.accent2}" opacity="0.66"/>

  ${textBlock(title.toUpperCase(), 92, titleY, titleMaxChars, titleMaxLines, titleSize, titleLine, p.text, 900, -1.4)}
  <rect x="92" y="${subtitleY - 64}" width="${width - 184}" height="6" rx="3" fill="${p.accent2}" opacity="0.55"/>
  ${textBlock(subtitle, 96, subtitleY, subtitleMaxChars, 4, subtitleSize, subtitleLine, p.sub, 650, 0, "Arial, sans-serif")}

  <rect x="90" y="${height - 276}" width="${width - 180}" height="142" rx="24" fill="${p.text}" opacity="0.07" stroke="${p.text}" stroke-opacity="0.17" stroke-width="2"/>
  <text x="96" y="${height - 318}" fill="${p.accent}" font-size="27" font-weight="900" font-family="Arial, sans-serif" letter-spacing="1.4">${mini}</text>
  ${textBlock(footer, 126, height - 204, 35, 2, 33, 43, p.text, 780, 0, "Arial, sans-serif")}
  <text x="92" y="${height - 72}" fill="${p.text}" fill-opacity="0.42" font-size="24" font-weight="800" font-family="Arial, sans-serif" letter-spacing="1.2">officialwhokeas Ai</text>
</svg>`;
}
export function packText(pack: GeneratedPack) {
  const schedule = pack.postingPlan
    .map((p) => `${p.time} - ${p.label}: ${p.task}`)
    .join("\n");
  return `DATE: ${pack.date}\nDAY: ${pack.dayLabel}\nNICHE: ${pack.niche}\nTOPIC: ${pack.mainTopic}\n\nPSYCHOLOGY TRIGGER:\nPrinciple: ${pack.psychologyTrigger?.principle || "Not set"}\nEmotion target: ${pack.psychologyTrigger?.emotionTarget || "Not set"}\nFormula: ${pack.psychologyTrigger?.hookFormula || "Not set"}\nWhy it works: ${pack.psychologyTrigger?.whyItWorks || "Not set"}\n\nPOSTING SCHEDULE:\n${schedule}\n\nGROWTH SCORE:\nStop power: ${pack.growthScore.stopPower}\nSave reason: ${pack.growthScore.saveReason}\nComment trigger: ${pack.growthScore.commentTrigger}\nSafety rule: ${pack.growthScore.safetyRule}\n\nCAPTION:\n${pack.caption}\n\nHASHTAGS:\n${pack.hashtags.join(" ")}\n\nREEL SCRIPT:\n${pack.reelScript.join("\n")}\n\nCAROUSEL:\n${pack.carousel.join("\n")}\n\nSIGNATURE POSTING SYSTEM:\nFormat: ${pack.recognitionSystem?.formatName || "Not set"}\nVisual fingerprint: ${pack.recognitionSystem?.visualFingerprint || "Not set"}\nFirst line rule: ${pack.recognitionSystem?.firstLineRule || "Not set"}\nCaption move: ${pack.recognitionSystem?.captionMove || "Not set"}\nStory sequence: ${pack.recognitionSystem?.storySequence || "Not set"}\nFollower action: ${pack.recognitionSystem?.followerAction || "Not set"}\n\nWHATSAPP REPORT:\n${pack.whatsappReport}`;
}

function escapeXml(str: string) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&apos;");
}
