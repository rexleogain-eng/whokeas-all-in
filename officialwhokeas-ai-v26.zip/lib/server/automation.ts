import sharp from "sharp";
import { cardSvg, GeneratedPack } from "@/lib/content";

export type PublishKind = "feed" | "story";

export function env(name: string) {
  return process.env[name]?.trim() || "";
}

export function cleanToken(raw: string) {
  let token = (raw || "").trim();
  token = token.replace(/^INSTAGRAM_ACCESS_TOKEN=/i, "").trim();
  token = token.replace(/^access_token=/i, "").trim();
  token = token.replace(/^Bearer\s+/i, "").trim();
  if ((token.startsWith('"') && token.endsWith('"')) || (token.startsWith("'") && token.endsWith("'"))) {
    token = token.slice(1, -1).trim();
  }
  // Tokens should not contain whitespace. This also fixes accidental line wrapping.
  token = token.replace(/\s+/g, "");
  return token;
}

export function envAny(names: string[]) {
  for (const name of names) {
    const value = env(name);
    if (value) return value;
  }
  return "";
}

export function getInstagramConfig() {
  const modeRaw = envAny(["INSTAGRAM_API_MODE", "META_INSTAGRAM_API_MODE"]).toLowerCase();
  const accessToken = cleanToken(envAny(["INSTAGRAM_ACCESS_TOKEN", "META_ACCESS_TOKEN"]));
  // Strong auto-detect: Instagram Login tokens commonly start with IG, while Facebook/Page tokens usually start with EA.
  // This prevents IGAA/IGQV tokens being sent to graph.facebook.com, which causes code 190: Cannot parse access token.
  let mode: "instagram_login" | "facebook_login" = "facebook_login";
  if (modeRaw === "instagram_login" || modeRaw === "instagram") mode = "instagram_login";
  else if (modeRaw === "facebook_login" || modeRaw === "facebook") mode = "facebook_login";
  else if (/^IG/i.test(accessToken)) mode = "instagram_login";

  const igUserId = envAny(["INSTAGRAM_IG_USER_ID", "META_IG_USER_ID"]);
  const graphVersion = env("META_GRAPH_VERSION") || env("INSTAGRAM_GRAPH_VERSION") || "v25.0";
  const graphBase = mode === "instagram_login"
    ? `https://graph.instagram.com/${graphVersion}`
    : `https://graph.facebook.com/${graphVersion}`;

  return { mode, modeRaw: modeRaw || "auto", accessToken, igUserId, graphVersion, graphBase };
}

export function requireOwner(request: Request) {
  const ownerSecret = env("OWNER_SECRET");
  if (!ownerSecret) {
    return { ok: false as const, status: 500, message: "OWNER_SECRET is missing." };
  }
  const supplied = request.headers.get("x-owner-key")?.trim() || "";
  const auth = request.headers.get("authorization")?.trim() || "";
  const cronSecret = env("CRON_SECRET");

  if (supplied === ownerSecret) return { ok: true as const };
  if (cronSecret && auth === `Bearer ${cronSecret}`) return { ok: true as const };
  return { ok: false as const, status: 401, message: "Unauthorized. Check OWNER_SECRET / CRON_SECRET." };
}

export async function svgToPng(svg: string, width: number, height: number) {
  return sharp(Buffer.from(svg)).resize(width, height, { fit: "fill" }).png().toBuffer();
}

export async function svgToJpeg(svg: string, width: number, height: number) {
  // Instagram Content Publishing is strict with image URLs.
  // JPEG is the safest accepted image format for feed/story publishing; PNG URLs can be rejected as invalid media.
  return sharp(Buffer.from(svg))
    .resize(width, height, { fit: "fill" })
    .flatten({ background: "#f8f2e7" })
    .jpeg({ quality: 94, progressive: false, mozjpeg: true })
    .toBuffer();
}

function encodePath(path: string) {
  return path.split("/").map(encodeURIComponent).join("/");
}

export async function uploadBufferToSupabase(path: string, buffer: Buffer, contentType = "image/png") {
  const supabaseUrl = envAny(["SUPABASE_URL", "NEXT_PUBLIC_SUPABASE_URL"]);
  const serviceKey = env("SUPABASE_SERVICE_ROLE_KEY");
  const bucket = env("SUPABASE_STORAGE_BUCKET") || "owai-generated";

  if (!supabaseUrl || !serviceKey) {
    throw new Error("Supabase URL or service role key is missing.");
  }

  const cleanPath = path.replace(/^\/+/, "");
  const uploadUrl = `${supabaseUrl}/storage/v1/object/${bucket}/${encodePath(cleanPath)}`;

  const res = await fetch(uploadUrl, {
    method: "POST",
    headers: {
      apikey: serviceKey,
      Authorization: `Bearer ${serviceKey}`,
      "Content-Type": contentType,
      "x-upsert": "true",
    },
    body: buffer as unknown as BodyInit,
    cache: "no-store",
  });

  const text = await res.text();
  if (!res.ok) {
    throw new Error(`Supabase Storage upload failed: ${text.slice(0, 500)}`);
  }

  return {
    path: cleanPath,
    publicUrl: `${supabaseUrl}/storage/v1/object/public/${bucket}/${encodePath(cleanPath)}`,
    result: text,
  };
}

export async function publishInstagramImage(input: {
  imageUrl: string;
  caption?: string;
  kind?: PublishKind;
}) {
  const cfg = getInstagramConfig();
  const accessToken = cfg.accessToken;
  const igUserId = cfg.igUserId;

  const debug = {
    mode: cfg.mode,
    graphBase: cfg.graphBase,
    graphVersion: cfg.graphVersion,
    igUserId,
    tokenPrefix: accessToken ? accessToken.slice(0, 6) : "missing",
    tokenLength: accessToken.length,
    imageUrl: input.imageUrl,
    kind: input.kind || "feed",
  };

  if (!accessToken || !igUserId) {
    return {
      ok: false,
      mode: "demo",
      message: "Instagram credentials missing. Add INSTAGRAM_ACCESS_TOKEN and INSTAGRAM_IG_USER_ID.",
      debug,
    };
  }

  const graphBase = cfg.graphBase;
  const baseParams = new URLSearchParams({ image_url: input.imageUrl });
  if (input.kind === "story") {
    baseParams.set("media_type", "STORIES");
  } else {
    baseParams.set("caption", input.caption || "");
  }

  function isTokenParseError(json: any) {
    const msg = String(json?.error?.message || json?.message || "").toLowerCase();
    return json?.error?.code === 190 || msg.includes("cannot parse access token") || msg.includes("invalid oauth access token");
  }

  async function postForm(url: string, body: URLSearchParams, authStyle: "bearer" | "query" | "body") {
    const finalUrl = authStyle === "query"
      ? `${url}?access_token=${encodeURIComponent(accessToken)}`
      : url;
    const finalBody = new URLSearchParams(body);
    if (authStyle === "body") finalBody.set("access_token", accessToken);
    const headers: Record<string, string> = { "Content-Type": "application/x-www-form-urlencoded" };
    if (authStyle === "bearer") headers.Authorization = `Bearer ${accessToken}`;
    const res = await fetch(finalUrl, {
      method: "POST",
      headers,
      body: finalBody,
      cache: "no-store",
    });
    const json = await res.json().catch(() => ({}));
    return { ok: res.ok, status: res.status, json, authStyle };
  }

  const createEndpoint = `${graphBase}/${encodeURIComponent(igUserId)}/media`;
  const authOrder: Array<"bearer" | "query" | "body"> = cfg.mode === "instagram_login"
    ? ["bearer", "query", "body"]
    : ["query", "body", "bearer"];

  let createAttempt: Awaited<ReturnType<typeof postForm>> | null = null;
  const createAttempts: unknown[] = [];
  for (const style of authOrder) {
    createAttempt = await postForm(createEndpoint, baseParams, style);
    createAttempts.push({ authStyle: style, status: createAttempt.status, ok: createAttempt.ok, result: createAttempt.json });
    if (createAttempt.ok && (createAttempt.json as any).id) break;
    if (!isTokenParseError(createAttempt.json)) break;
  }

  const containerJson: any = createAttempt?.json || {};
  if (!createAttempt?.ok || !containerJson.id) {
    return {
      ok: false,
      step: "create_container",
      debug,
      result: containerJson,
      attempts: createAttempts,
      note: "v25 tried bearer/query/body token styles for Instagram Login tokens. If all report code 190, regenerate the IGAA token and make sure it is saved on one line.",
    };
  }

  const publishEndpoint = `${graphBase}/${encodeURIComponent(igUserId)}/media_publish`;
  const publishBody = new URLSearchParams({ creation_id: containerJson.id });
  let publishAttempt: Awaited<ReturnType<typeof postForm>> | null = null;
  const publishAttempts: unknown[] = [];
  for (const style of authOrder) {
    publishAttempt = await postForm(publishEndpoint, publishBody, style);
    publishAttempts.push({ authStyle: style, status: publishAttempt.status, ok: publishAttempt.ok, result: publishAttempt.json });
    if (publishAttempt.ok) break;
    if (!isTokenParseError(publishAttempt.json)) break;
  }

  const publishJson: any = publishAttempt?.json || {};
  if (!publishAttempt?.ok) {
    return {
      ok: false,
      step: "publish",
      debug,
      result: publishJson,
      attempts: publishAttempts,
      containerId: containerJson.id,
    };
  }

  return { ok: true, result: publishJson, containerId: containerJson.id, debug };
}

export async function sendWhatsAppText(report: string, templateValues?: {
  posts?: string;
  stories?: string;
  angle?: string;
  action?: string;
}) {
  const token = envAny(["WHATSAPP_ACCESS_TOKEN", "WHATSAPP_TOKEN"]);
  const phoneNumberId = env("WHATSAPP_PHONE_NUMBER_ID");
  const to = envAny(["WHATSAPP_TO_NUMBER", "OWNER_WHATSAPP_NUMBER"]);
  const templateName = env("WHATSAPP_TEMPLATE_NAME");
  const templateLang = env("WHATSAPP_TEMPLATE_LANG") || "en_US";
  const graphVersion = env("META_GRAPH_VERSION") || "v21.0";

  if (!token || !phoneNumberId || !to) {
    return {
      ok: false,
      mode: "manual-free",
      message: "WhatsApp credentials missing. Add WHATSAPP_ACCESS_TOKEN, WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_TO_NUMBER.",
      manualUrl: `https://wa.me/?text=${encodeURIComponent(report)}`,
      report,
    };
  }

  const body = templateName
    ? {
        messaging_product: "whatsapp",
        to,
        type: "template",
        template: {
          name: templateName,
          language: { code: templateLang },
          components: [
            {
              type: "body",
              parameters: [
                { type: "text", text: (templateValues?.posts || "1 feed post").slice(0, 80) },
                { type: "text", text: (templateValues?.stories || "4 story posts").slice(0, 80) },
                { type: "text", text: (templateValues?.angle || "Psychology Growth Engine").slice(0, 120) },
                { type: "text", text: (templateValues?.action || "Post today's feed card and stories").slice(0, 160) },
              ],
            },
          ],
        },
      }
    : {
        messaging_product: "whatsapp",
        to,
        type: "text",
        text: { body: report },
      };

  const res = await fetch(`https://graph.facebook.com/${graphVersion}/${phoneNumberId}/messages`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
    cache: "no-store",
  });

  const json = await res.json();
  if (!res.ok) return { ok: false, result: json };
  return { ok: true, result: json };
}

export async function uploadPackCard(pack: GeneratedPack, kind: PublishKind, storyIndex?: number) {
  const iso = pack.isoDate;
  if (kind === "feed") {
    const svg = cardSvg(pack.feedCard.headline, pack.feedCard.subline, pack.feedCard.footer, "feed", pack.palette);
    const buffer = await svgToJpeg(svg, 1080, 1080);
    return uploadBufferToSupabase(`${iso}/feed-${iso}.jpg`, buffer, "image/jpeg");
  }

  const story = pack.stories[storyIndex ?? 0];
  const svg = cardSvg(story.title, story.subtitle, story.cta, "story", pack.palette);
  const buffer = await svgToJpeg(svg, 1080, 1920);
  return uploadBufferToSupabase(`${iso}/story-${story.slot}-${iso}.jpg`, buffer, "image/jpeg");
}
