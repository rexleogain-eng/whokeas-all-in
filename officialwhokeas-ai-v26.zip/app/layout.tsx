import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "officialwhokeas Ai",
  description: "Brain + memory faceless Instagram content system",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
