"use client";

import { useEffect, useMemo, useState } from "react";
import JSZip from "jszip";
import {
  Archive,
  CalendarClock,
  Camera,
  Copy,
  Download,
  MessageCircle,
  Sparkles,
  Wand2,
  Smartphone,
} from "lucide-react";
import {
  AccountGoal,
  cardSvg,
  ContentIntensity,
  GeneratedPack,
  packText,
} from "@/lib/content";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
};

const nicheOptions = [
  { value: "psychomix", label: "Psychology Growth — Recommended" },
  { value: "curiosity", label: "Curiosity Hooks" },
  { value: "moneypsych", label: "Money Psychology" },
  { value: "socialtruth", label: "Social Truths" },
  { value: "ai", label: "AI Curiosity" },
  { value: "study", label: "Study Psychology" },
  { value: "trading", label: "Trading Psychology" },
];

const intensityOptions: { value: ContentIntensity; label: string }[] = [
  { value: "normal", label: "Normal / clean" },
  { value: "crazy", label: "Crazy attention" },
  { value: "deep", label: "Deep psychology — Recommended" },
  { value: "money", label: "Money hooks" },
  { value: "study", label: "Study hooks" },
  { value: "trading", label: "Trading psychology" },
];

const goalOptions: { value: AccountGoal; label: string }[] = [
  { value: "saves", label: "Get saves" },
  { value: "comments", label: "Get comments" },
  { value: "followers", label: "Get followers" },
  { value: "dms", label: "Get DMs" },
  { value: "traffic", label: "Get profile/link visits" },
];

type PostedKey = "feed" | "morning" | "noon" | "evening" | "night" | "caption";
type PostedMap = Record<string, Partial<Record<PostedKey, boolean>>>;

type VaultRecord = {
  id: string;
  savedAt: string;
  batchId: string;
  source: "auto" | "manual";
  intensity: ContentIntensity;
  accountGoal: AccountGoal;
  pack: GeneratedPack;
};

const STORAGE_KEYS = {
  week: "officialwhokeas_ai_week_v11",
  posted: "officialwhokeas_ai_posted_v11",
  vault: "officialwhokeas_ai_vault_v11",
  settings: "officialwhokeas_ai_settings_v11",
  ownerKey: "officialwhokeas_ai_owner_key_v11",
};


type ClientPalette = {
  bg1: string;
  bg2: string;
  accent: string;
  accent2: string;
  text: string;
  sub: string;
};

const clientPalettes: Record<string, ClientPalette> = {
  emerald: { bg1: "#f2eadc", bg2: "#d6c7a9", accent: "#23483d", accent2: "#b85c38", text: "#1c1a17", sub: "#4d463d" },
  royal: { bg1: "#eee7dc", bg2: "#c7cad7", accent: "#25365f", accent2: "#9b5d38", text: "#191b24", sub: "#42485c" },
  sunset: { bg1: "#f3dfc8", bg2: "#d49b73", accent: "#6f2f22", accent2: "#d68b54", text: "#24150f", sub: "#5b382a" },
  midnight: { bg1: "#e9e3d5", bg2: "#a8a198", accent: "#111111", accent2: "#8c6f4f", text: "#151515", sub: "#4b4843" },
  gold: { bg1: "#f4ead1", bg2: "#d0ad69", accent: "#5f4318", accent2: "#a35d22", text: "#211705", sub: "#5d4a22" },
  aqua: { bg1: "#e8eee9", bg2: "#a8c6bd", accent: "#1c4b47", accent2: "#b35b3e", text: "#14201e", sub: "#405551" },
};

function getClientPalette(name: GeneratedPack["palette"]): ClientPalette {
  return clientPalettes[String(name)] || clientPalettes.emerald;
}

function drawRoundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + width - r, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + r);
  ctx.lineTo(x + width, y + height - r);
  ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
  ctx.lineTo(x + r, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function wrapCanvasWords(
  ctx: CanvasRenderingContext2D,
  input: string,
  maxWidth: number,
  maxLines: number,
) {
  const words = input.replace(/\s+/g, " ").trim().split(" ").filter(Boolean);
  const lines: string[] = [];
  let current = "";

  for (const word of words) {
    const next = current ? `${current} ${word}` : word;
    if (ctx.measureText(next).width > maxWidth && current) {
      lines.push(current);
      current = word;
    } else {
      current = next;
    }
  }

  if (current) lines.push(current);
  return lines.slice(0, maxLines);
}

function drawWrappedText(
  ctx: CanvasRenderingContext2D,
  input: string,
  x: number,
  y: number,
  maxWidth: number,
  maxLines: number,
  font: string,
  lineHeight: number,
  color: string,
) {
  ctx.font = font;
  ctx.fillStyle = color;
  ctx.textBaseline = "alphabetic";
  const lines = wrapCanvasWords(ctx, input, maxWidth, maxLines);
  lines.forEach((line, index) => ctx.fillText(line, x, y + index * lineHeight));
}

function cardCanvasBlob(
  title: string,
  subtitle: string,
  footer: string,
  kind: "feed" | "story",
  palette: GeneratedPack["palette"],
  mimeType: "image/png" | "image/jpeg",
): Promise<Blob> {
  const width = 1080;
  const height = kind === "story" ? 1920 : 1350;
  const p = getClientPalette(palette);
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) return Promise.reject(new Error("Canvas is not supported in this browser."));

  const bg = ctx.createLinearGradient(0, 0, width, height);
  bg.addColorStop(0, p.bg1);
  bg.addColorStop(0.64, p.bg2);
  bg.addColorStop(1, p.bg1);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);

  // Fine editorial grid. Canvas-rendered text avoids the SVG font-box bug seen on Instagram.
  ctx.save();
  ctx.globalAlpha = 0.055;
  ctx.strokeStyle = p.text;
  ctx.lineWidth = 1;
  for (let x = 0; x <= width; x += 36) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  for (let y = 0; y <= height; y += 36) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }
  ctx.restore();

  ctx.save();
  ctx.strokeStyle = p.text;
  ctx.globalAlpha = 0.42;
  ctx.lineWidth = 3;
  drawRoundRect(ctx, 48, 48, width - 96, height - 96, 42);
  ctx.stroke();
  ctx.restore();

  ctx.save();
  ctx.fillStyle = "rgba(255,255,255,0.18)";
  ctx.strokeStyle = p.text;
  ctx.globalAlpha = 0.9;
  ctx.lineWidth = 2;
  drawRoundRect(ctx, 78, 78, width - 156, height - 156, 28);
  ctx.fill();
  ctx.globalAlpha = 0.13;
  ctx.stroke();
  ctx.restore();

  const label = kind === "story" ? "DAILY NOTE" : "EDITORIAL NOTE";
  const mini = kind === "story" ? "save - reply - share" : "save it if it found you";
  const edition = String((title.length + subtitle.length) % 9 + 1).padStart(2, "0");
  const pillW = kind === "story" ? 330 : 300;
  ctx.fillStyle = p.text;
  drawRoundRect(ctx, 92, 102, pillW, 64, 32);
  ctx.fill();

  ctx.font = "900 27px Arial, Helvetica, sans-serif";
  ctx.fillStyle = p.bg1;
  ctx.fillText(label, 120, 144);

  ctx.font = "900 42px Georgia, 'Times New Roman', serif";
  ctx.fillStyle = p.text;
  ctx.globalAlpha = 0.56;
  ctx.fillText(edition, width - 210, 150);
  ctx.globalAlpha = 1;

  const topBandY = kind === "story" ? 250 : 215;
  ctx.save();
  ctx.strokeStyle = p.text;
  ctx.globalAlpha = 0.22;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(92, topBandY);
  ctx.lineTo(width - 92, topBandY);
  ctx.stroke();
  ctx.restore();
  ctx.save();
  ctx.globalAlpha = 0.66;
  ctx.fillStyle = p.accent2;
  ctx.beginPath();
  ctx.arc(width - 112, topBandY, 9, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  const titleY = kind === "story" ? 540 : 330;
  const titleSize = kind === "story" ? 86 : 76;
  const titleLine = kind === "story" ? 100 : 86;
  const titleMaxLines = kind === "story" ? 6 : 6;
  drawWrappedText(
    ctx,
    title.toUpperCase(),
    92,
    titleY,
    width - 184,
    titleMaxLines,
    `900 ${titleSize}px Georgia, 'Times New Roman', serif`,
    titleLine,
    p.text,
  );

  const subtitleY = kind === "story" ? 1120 : 790;
  ctx.save();
  ctx.fillStyle = p.accent2;
  ctx.globalAlpha = 0.55;
  drawRoundRect(ctx, 92, subtitleY - 64, width - 184, 6, 3);
  ctx.fill();
  ctx.restore();

  drawWrappedText(
    ctx,
    subtitle,
    96,
    subtitleY,
    width - 192,
    4,
    `${kind === "story" ? 700 : 650} ${kind === "story" ? 45 : 38}px Arial, Helvetica, sans-serif`,
    kind === "story" ? 60 : 52,
    p.sub,
  );

  ctx.save();
  ctx.fillStyle = p.text;
  ctx.globalAlpha = 0.07;
  drawRoundRect(ctx, 90, height - 276, width - 180, 142, 24);
  ctx.fill();
  ctx.globalAlpha = 0.17;
  ctx.strokeStyle = p.text;
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();

  ctx.font = "900 27px Arial, Helvetica, sans-serif";
  ctx.fillStyle = p.accent;
  ctx.fillText(mini, 96, height - 318);

  drawWrappedText(
    ctx,
    footer,
    126,
    height - 204,
    width - 252,
    2,
    "780 33px Arial, Helvetica, sans-serif",
    43,
    p.text,
  );

  ctx.font = "800 24px Arial, Helvetica, sans-serif";
  ctx.fillStyle = p.text;
  ctx.globalAlpha = 0.42;
  ctx.fillText("officialwhokeas Ai", 92, height - 72);
  ctx.globalAlpha = 1;

  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error(`${mimeType} export failed.`))),
      mimeType,
      mimeType === "image/jpeg" ? 0.92 : 0.95,
    );
  });
}

const visiblePostedKeys: PostedKey[] = [
  "morning",
  "noon",
  "feed",
  "evening",
  "night",
];

function downloadBlob(filename: string, blob: Blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

async function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Could not read PNG blob."));
    reader.readAsDataURL(blob);
  });
}

function downloadText(filename: string, text: string) {
  downloadBlob(
    filename,
    new Blob([text], { type: "text/plain;charset=utf-8" }),
  );
}

function downloadSvg(filename: string, svg: string) {
  downloadBlob(
    filename,
    new Blob([svg], { type: "image/svg+xml;charset=utf-8" }),
  );
}

async function svgToImageBlob(
  svg: string,
  width: number,
  height: number,
  mimeType: "image/png" | "image/jpeg" = "image/png",
): Promise<Blob> {
  const blob = new Blob([svg], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(blob);

  try {
    const img = new Image();
    img.decoding = "async";
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error(`Could not render SVG as ${mimeType}.`));
      img.src = url;
    });

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas is not supported in this browser.");

    // JPEG cannot keep transparency. Fill with the card paper color first so
    // Instagram fetches a clean photo-style file instead of a transparent canvas.
    if (mimeType === "image/jpeg") {
      ctx.fillStyle = "#f8f2e7";
      ctx.fillRect(0, 0, width, height);
    }
    ctx.drawImage(img, 0, 0, width, height);

    const imageBlob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob(resolve, mimeType, mimeType === "image/jpeg" ? 0.92 : 0.95),
    );
    if (!imageBlob) throw new Error(`${mimeType} export failed.`);
    return imageBlob;
  } finally {
    URL.revokeObjectURL(url);
  }
}

async function pngFromCard(
  title: string,
  subtitle: string,
  footer: string,
  kind: "feed" | "story",
  palette: GeneratedPack["palette"],
) {
  return cardCanvasBlob(title, subtitle, footer, kind, palette, "image/png");
}

async function jpgFromCard(
  title: string,
  subtitle: string,
  footer: string,
  kind: "feed" | "story",
  palette: GeneratedPack["palette"],
) {
  return cardCanvasBlob(title, subtitle, footer, kind, palette, "image/jpeg");
}

async function downloadCardPng(
  filename: string,
  title: string,
  subtitle: string,
  footer: string,
  kind: "feed" | "story",
  palette: GeneratedPack["palette"],
) {
  const png = await pngFromCard(title, subtitle, footer, kind, palette);
  downloadBlob(filename, png);
}

function fileSafe(name: string) {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 60);
}

function isV6Pack(pack: GeneratedPack) {
  return Boolean(pack?.postingPlan?.length && pack?.growthScore?.stopPower);
}

function scheduleKey(label: string): PostedKey {
  const lower = label.toLowerCase();
  if (lower.includes("morning")) return "morning";
  if (lower.includes("noon")) return "noon";
  if (lower.includes("night")) return "night";
  if (lower.includes("engagement") || lower.includes("evening"))
    return "evening";
  return "feed";
}

function progressFor(pack: GeneratedPack, posted: PostedMap) {
  const day = posted[pack.isoDate] || {};
  const done = visiblePostedKeys.filter((key) => day[key]).length;
  return {
    done,
    total: visiblePostedKeys.length,
    percent: Math.round((done / visiblePostedKeys.length) * 100),
  };
}

function scorePack(pack: GeneratedPack) {
  const stop = pack.growthScore.stopPower.toLowerCase().includes("very")
    ? 92
    : 82;
  const commentBonus = pack.growthScore.commentTrigger.length > 45 ? 4 : 0;
  const topicBonus = pack.mainTopic.length < 55 ? 3 : 0;
  return stop + commentBonus + topicBonus;
}

function uniqueTopicsFrom(vault: VaultRecord[], week: GeneratedPack[]) {
  return Array.from(
    new Set([
      ...vault.map((item) => item.pack.mainTopic),
      ...week.map((item) => item.mainTopic),
    ]),
  ).filter(Boolean);
}

export default function Home() {
  const [pack, setPack] = useState<GeneratedPack | null>(null);
  const [week, setWeek] = useState<GeneratedPack[]>([]);
  const [niche, setNiche] = useState("psychomix");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");
  const [posted, setPosted] = useState<PostedMap>({});
  const [vault, setVault] = useState<VaultRecord[]>([]);
  const [intensity, setIntensity] = useState<ContentIntensity>("deep");
  const [accountGoal, setAccountGoal] = useState<AccountGoal>("saves");
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [ownerKey, setOwnerKey] = useState("");
  const [cloudLoading, setCloudLoading] = useState(false);
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);
  const [loginStatus, setLoginStatus] = useState("");
  const [hydrationReady, setHydrationReady] = useState(false);
  const [clientLoaded, setClientLoaded] = useState(false);

  function rememberPacks(packs: GeneratedPack[], source: "auto" | "manual" = "auto") {
    const batchId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const savedAt = new Date().toISOString();
    setVault((prev) => {
      const existing = new Set(prev.map((item) => item.id));
      const newItems = packs
        .map((item) => ({
          id: `${item.isoDate}-${item.mainTopic}-${intensity}-${accountGoal}`,
          savedAt,
          batchId,
          source,
          intensity,
          accountGoal,
          pack: item,
        }))
        .filter((item) => !existing.has(item.id));
      return [...newItems, ...prev].slice(0, 120);
    });
  }

  function topicsToAvoid() {
    return uniqueTopicsFrom(vault, week).slice(0, 60);
  }

  async function generate(days = 1) {
    setLoading(true);
    setStatus("");
    try {
      const res = await fetch(
        `/api/autopilot/daily?niche=${niche}&days=${days}&intensity=${intensity}&goal=${accountGoal}&avoid=${encodeURIComponent(topicsToAvoid().join("|"))}`,
        { cache: "no-store" },
      );
      const data = await res.json();

      if (data.packs) {
        setWeek(data.packs);
        setPack(data.packs[0]);
        localStorage.setItem(
          STORAGE_KEYS.week,
          JSON.stringify(data.packs),
        );
        rememberPacks(data.packs);
        setStatus(`${data.packs.length}-day growth calendar is ready. Brain saved it and protected repeated topics.`);
      } else {
        setPack(data);
        setWeek([data]);
        localStorage.setItem(
          STORAGE_KEYS.week,
          JSON.stringify([data]),
        );
        rememberPacks([data]);
        setStatus("Today's growth pack is ready and saved to the content vault.");
      }
    } catch (error) {
      setStatus(
        error instanceof Error ? error.message : "Could not generate content.",
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    setHydrationReady(true);
    const ownerKeySaved = localStorage.getItem(STORAGE_KEYS.ownerKey);
    if (ownerKeySaved) {
      // Keep the saved key for convenience, but do not unlock automatically.
      // This prevents the login page from disappearing because of old localStorage/PWA cache.
      setOwnerKey(ownerKeySaved);
      setIsUnlocked(false);
      setLoginStatus("Enter password and press Login to unlock this session.");
    }

    const settingsSaved = localStorage.getItem(STORAGE_KEYS.settings);
    if (settingsSaved) {
      try {
        const parsed = JSON.parse(settingsSaved) as {
          niche?: string;
          intensity?: ContentIntensity;
          accountGoal?: AccountGoal;
        };
        if (parsed.niche) setNiche(parsed.niche);
        if (parsed.intensity) setIntensity(parsed.intensity);
        if (parsed.accountGoal) setAccountGoal(parsed.accountGoal);
      } catch {}
    }

    const vaultSaved = localStorage.getItem(STORAGE_KEYS.vault);
    if (vaultSaved) {
      try {
        setVault(JSON.parse(vaultSaved) as VaultRecord[]);
      } catch {}
    }

    const postedSaved = localStorage.getItem(STORAGE_KEYS.posted);
    if (postedSaved) {
      try {
        setPosted(JSON.parse(postedSaved) as PostedMap);
      } catch {}
    }

    const saved = localStorage.getItem(STORAGE_KEYS.week);
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as GeneratedPack[];
        if (parsed.length && parsed.every(isV6Pack)) {
          setWeek(parsed);
          setPack(parsed[0]);
          return;
        }
      } catch {}
    }
    generate(7);
    setClientLoaded(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!clientLoaded) return;
    localStorage.setItem(
      STORAGE_KEYS.posted,
      JSON.stringify(posted),
    );
  }, [posted, clientLoaded]);

  useEffect(() => {
    if (!clientLoaded) return;
    localStorage.setItem(STORAGE_KEYS.vault, JSON.stringify(vault));
  }, [vault, clientLoaded]);

  useEffect(() => {
    if (!clientLoaded) return;
    localStorage.setItem(
      STORAGE_KEYS.settings,
      JSON.stringify({ niche, intensity, accountGoal }),
    );
  }, [niche, intensity, accountGoal, clientLoaded]);

  useEffect(() => {
    if (!clientLoaded) return;
    if (ownerKey) localStorage.setItem(STORAGE_KEYS.ownerKey, ownerKey);
  }, [ownerKey, clientLoaded]);

  useEffect(() => {
    const onBeforeInstall = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPromptEvent);
    };

    window.addEventListener("beforeinstallprompt", onBeforeInstall);
    return () => window.removeEventListener("beforeinstallprompt", onBeforeInstall);
  }, []);

  useEffect(() => {
    if (typeof window === "undefined" || !("serviceWorker" in navigator)) return;
    window.addEventListener("load", () => {
      navigator.serviceWorker
        .register("/sw.js")
        .then(() => setStatus((current) => current || "PWA offline worker is active."))
        .catch(() => setStatus((current) => current || "PWA install works online, but offline worker could not register."));
    });
  }, []);

  async function loginToSystem() {
    const key = ownerKey.trim();
    if (!key) {
      setLoginStatus("Enter your officialwhokeas Ai password first.");
      return;
    }

    setAuthLoading(true);
    setLoginStatus("Checking access...");
    try {
      const res = await fetch("/api/auth/check", {
        method: "POST",
        headers: { "x-owner-key": key },
        cache: "no-store",
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setLoginStatus(data.message || "Login failed. Check OWNER_SECRET.");
        setIsUnlocked(false);
        return;
      }
      setIsUnlocked(true);
      setOwnerKey(key);
      localStorage.setItem(STORAGE_KEYS.ownerKey, key);
      setStatus("Login successful. System access unlocked.");
      setLoginStatus("Access granted.");
    } catch (error) {
      setLoginStatus(error instanceof Error ? error.message : "Login failed.");
      setIsUnlocked(false);
    } finally {
      setAuthLoading(false);
    }
  }

  function logoutFromSystem() {
    setIsUnlocked(false);
    setOwnerKey("");
    setStatus("");
    setLoginStatus("Logged out.");
    localStorage.removeItem(STORAGE_KEYS.ownerKey);
  }

  async function installApp() {
    if (!installPrompt) {
      setStatus("Install button appears when the browser allows this app to be installed. On Chrome, use the install icon in the address bar if you see it.");
      return;
    }
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    setInstallPrompt(null);
    setStatus(choice.outcome === "accepted" ? "officialwhokeas Ai install started." : "Install dismissed. You can continue using it in the browser.");
  }


  const hashtags = useMemo(() => pack?.hashtags.join(" ") || "", [pack]);
  const currentProgress = pack
    ? progressFor(pack, posted)
    : { done: 0, total: 5, percent: 0 };
  const usedTopicCount = uniqueTopicsFrom(vault, week).length;
  const bestPack = useMemo(() => {
    const packs = week.length ? week : pack ? [pack] : [];
    return packs.slice().sort((a, b) => scorePack(b) - scorePack(a))[0] || null;
  }, [pack, week]);

  function togglePosted(date: string, key: PostedKey) {
    setPosted((prev) => ({
      ...prev,
      [date]: {
        ...(prev[date] || {}),
        [key]: !prev[date]?.[key],
      },
    }));
  }

  function markSelectedDayDone() {
    if (!pack) return;
    setPosted((prev) => ({
      ...prev,
      [pack.isoDate]: Object.fromEntries(
        visiblePostedKeys.map((key) => [key, true]),
      ) as Partial<Record<PostedKey, boolean>>,
    }));
    setStatus("Selected day marked as posted.");
  }

  function resetSelectedDay() {
    if (!pack) return;
    setPosted((prev) => ({ ...prev, [pack.isoDate]: {} }));
    setStatus("Selected day reset.");
  }

  function resetAllPosted() {
    setPosted({});
    setStatus("All posted marks cleared.");
  }

  function clearVault() {
    setVault([]);
    setStatus("Content vault cleared. Used-topic protection will restart from this week only.");
  }

  async function saveCloudMemory() {
    setCloudLoading(true);
    setStatus("Saving cloud memory to Supabase...");
    try {
      const res = await fetch("/api/cloud/save", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-owner-key": ownerKey,
        },
        body: JSON.stringify({
          vault,
          posted,
          settings: { niche, intensity, accountGoal },
          week,
          currentPack: pack,
          savedFrom: typeof window !== "undefined" ? window.location.hostname : "browser",
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        const details = data.details ? ` Details: ${String(data.details).slice(0, 220)}` : "";
        setStatus(`${data.message || "Cloud memory save failed."}${details}`);
        return;
      }
      setStatus(data.message || "Cloud memory saved. You can refresh and load it back.");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Cloud memory save failed.");
    } finally {
      setCloudLoading(false);
    }
  }

  async function loadCloudMemory() {
    setCloudLoading(true);
    setStatus("Loading cloud memory from Supabase...");
    try {
      const res = await fetch("/api/cloud/load", {
        method: "GET",
        headers: { "x-owner-key": ownerKey },
        cache: "no-store",
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        const details = data.details ? ` Details: ${String(data.details).slice(0, 220)}` : "";
        setStatus(`${data.message || "Cloud memory load failed."}${details}`);
        return;
      }
      if (!data.payload) {
        setStatus(data.message || "No cloud memory found yet. Click Cloud Save first.");
        return;
      }

      const payload = data.payload as {
        vault?: VaultRecord[];
        posted?: PostedMap;
        settings?: { niche?: string; intensity?: ContentIntensity; accountGoal?: AccountGoal };
        week?: GeneratedPack[];
        currentPack?: GeneratedPack;
      };

      if (payload.vault) setVault(payload.vault);
      if (payload.posted) setPosted(payload.posted);
      if (payload.settings?.niche) setNiche(payload.settings.niche);
      if (payload.settings?.intensity) setIntensity(payload.settings.intensity);
      if (payload.settings?.accountGoal) setAccountGoal(payload.settings.accountGoal);
      if (payload.week?.length) {
        setWeek(payload.week);
        setPack(payload.currentPack || payload.week[0]);
        localStorage.setItem(STORAGE_KEYS.week, JSON.stringify(payload.week));
      }
      setStatus("Cloud memory loaded and applied to this browser.");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Cloud memory load failed.");
    } finally {
      setCloudLoading(false);
    }
  }

  async function testCloudHealth() {
    setStatus("Checking cloud health...");
    try {
      const res = await fetch("/api/cloud/health", { cache: "no-store" });
      const data = await res.json();
      const table = data.table?.ok ? "table ok" : data.table?.checked ? `table problem: ${data.table.message}` : "table not checked";
      setStatus(`Cloud health: owner key ${data.env?.OWNER_SECRET ? "ok" : "missing"}, Supabase URL ${data.env?.SUPABASE_URL ? "ok" : "missing"}, service key ${data.env?.SUPABASE_SERVICE_ROLE_KEY ? "ok" : "missing"}, ${table}.`);
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Cloud health check failed.");
    }
  }

  async function copyMemorySummary() {
    const lines = vault.slice(0, 30).map((item, index) =>
      `${index + 1}. ${item.pack.date} — ${item.pack.mainTopic} — ${item.intensity}/${item.accountGoal}`
    );
    await navigator.clipboard.writeText(
      `officialwhokeas Ai Memory Summary\nSaved packs: ${vault.length}\nUsed topics: ${usedTopicCount}\nBest current post: ${bestPack?.mainTopic || "None"}\n\n${lines.join("\n")}`
    );
    setStatus("Memory summary copied.");
  }

  function downloadMemoryJson() {
    downloadText(
      "officialwhokeas-ai-memory.json",
      JSON.stringify({ vault, posted, settings: { niche, intensity, accountGoal } }, null, 2),
    );
    setStatus("Memory backup downloaded.");
  }

  async function copyCaption() {
    if (!pack) return;
    await navigator.clipboard.writeText(`${pack.caption}\n\n${hashtags}`);
    setPosted((prev) => ({
      ...prev,
      [pack.isoDate]: { ...(prev[pack.isoDate] || {}), caption: true },
    }));
    setStatus("Caption + hashtags copied.");
  }

  async function copyChecklist() {
    if (!pack) return;
    const text = `POSTING CHECKLIST — ${pack.date}\n\n${pack.postingPlan.map((p) => `${p.time} — ${p.label}\n${p.task}`).join("\n\n")}\n\nCaption copied separately. Topic: ${pack.mainTopic}`;
    await navigator.clipboard.writeText(text);
    setStatus("Daily posting checklist copied.");
  }

  async function copySignatureGuide() {
    if (!pack?.recognitionSystem) return;
    const r = pack.recognitionSystem;
    const text = `officialwhokeas Ai Signature Posting Guide\n\nFormat: ${r.formatName}\nVisual fingerprint: ${r.visualFingerprint}\nFirst line rule: ${r.firstLineRule}\nCaption move: ${r.captionMove}\nStory rhythm: ${r.storySequence}\nFollower action: ${r.followerAction}`;
    await navigator.clipboard.writeText(text);
    setStatus("Signature posting guide copied.");
  }


  async function sendWhatsAppReport() {
    if (!pack) return;
    if (!ownerKey) {
      setStatus("Paste your Cloud password / OWNER_SECRET first, then send the WhatsApp report.");
      return;
    }
    setStatus("Preparing WhatsApp report...");
    const res = await fetch("/api/whatsapp/report", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-owner-key": ownerKey },
      body: JSON.stringify({
        report: pack.whatsappReport,
        posts: "1 feed post",
        stories: `${pack.stories.length} story posts`,
        angle: pack.psychologyTrigger?.principle || pack.mainTopic || pack.niche,
        action: pack.postingPlan?.[0]?.task || "Post today's feed card and stories",
      }),
    });
    const data = await res.json();
    if (data.manualUrl) {
      const opened = window.open(data.manualUrl, "_blank");
      if (!opened) window.location.href = data.manualUrl;
      setStatus(
        "WhatsApp API is not connected or missing credentials. I opened the manual WhatsApp link instead.",
      );
    } else {
      setStatus(
        data.ok
          ? "WhatsApp report sent. Check your WhatsApp now."
          : `WhatsApp report failed: ${JSON.stringify(data.result || data.message || data).slice(0, 350)}`,
      );
    }
  }

  function downloadFeedSvg() {
    if (!pack) return;
    downloadSvg(
      `feed-card-${pack.isoDate}.svg`,
      cardSvg(
        pack.feedCard.headline,
        pack.feedCard.subline,
        pack.feedCard.footer,
        "feed",
        pack.palette,
      ),
    );
  }

  function downloadStorySvg(index: number) {
    if (!pack) return;
    const story = pack.stories[index];
    downloadSvg(
      `story-${story.slot}-${pack.isoDate}.svg`,
      cardSvg(story.title, story.subtitle, story.cta, "story", pack.palette),
    );
  }

  async function downloadFeedPng() {
    if (!pack) return;
    setStatus("Exporting feed card as PNG...");
    await downloadCardPng(
      `feed-card-${pack.isoDate}.png`,
      pack.feedCard.headline,
      pack.feedCard.subline,
      pack.feedCard.footer,
      "feed",
      pack.palette,
    );
    setStatus("Feed card PNG downloaded. Upload it directly to Instagram.");
  }

  async function downloadStoryPng(index: number) {
    if (!pack) return;
    const story = pack.stories[index];
    setStatus(`Exporting ${story.slot} story as PNG...`);
    await downloadCardPng(
      `story-${story.slot}-${pack.isoDate}.png`,
      story.title,
      story.subtitle,
      story.cta,
      "story",
      pack.palette,
    );
    setStatus(`${story.slot} story PNG downloaded.`);
  }

  async function downloadTodayZip() {
    if (!pack) return;
    setStatus("Creating today's ZIP pack...");
    const zip = new JSZip();
    const folder = zip.folder(`${pack.isoDate}-${fileSafe(pack.mainTopic)}`)!;
    folder.file("caption-script-checklist.txt", packText(pack));
    folder.file(
      `feed-${pack.isoDate}.png`,
      await pngFromCard(
        pack.feedCard.headline,
        pack.feedCard.subline,
        pack.feedCard.footer,
        "feed",
        pack.palette,
      ),
    );

    for (const story of pack.stories) {
      folder.file(
        `story-${story.slot}-${pack.isoDate}.png`,
        await pngFromCard(
          story.title,
          story.subtitle,
          story.cta,
          "story",
          pack.palette,
        ),
      );
    }

    const blob = await zip.generateAsync({ type: "blob" });
    downloadBlob(`faceless-content-${pack.isoDate}.zip`, blob);
    setStatus("Today's ZIP downloaded: feed PNG + 4 stories + checklist file.");
  }

  async function downloadWeekZip() {
    const packs = week.length ? week : pack ? [pack] : [];
    if (!packs.length) return;

    setStatus("Creating content ZIP. Wait a little...");
    const zip = new JSZip();
    const summary: string[] = [];

    for (const p of packs) {
      const folder = zip.folder(`${p.isoDate}-${fileSafe(p.mainTopic)}`)!;
      folder.file("caption-script-checklist.txt", packText(p));
      folder.file(
        `feed-${p.isoDate}.png`,
        await pngFromCard(
          p.feedCard.headline,
          p.feedCard.subline,
          p.feedCard.footer,
          "feed",
          p.palette,
        ),
      );
      for (const story of p.stories) {
        folder.file(
          `story-${story.slot}-${p.isoDate}.png`,
          await pngFromCard(
            story.title,
            story.subtitle,
            story.cta,
            "story",
            p.palette,
          ),
        );
      }
      summary.push(`${p.date} (${p.dayLabel}) - ${p.niche} - ${p.mainTopic}`);
    }

    zip.file("posting-calendar.txt", summary.join("\n"));
    zip.file("plan.json", JSON.stringify(packs, null, 2));
    const blob = await zip.generateAsync({ type: "blob" });
    downloadBlob(`faceless-growth-content-plan.zip`, blob);
    setStatus(
      "Plan ZIP downloaded. It contains posts, stories, captions, scripts, and calendar.",
    );
  }

  async function uploadBlobToCloud(filename: string, blob: Blob) {
    if (!ownerKey) throw new Error("Paste your Cloud password / OWNER_SECRET first.");
    const base64 = await blobToBase64(blob);
    const res = await fetch("/api/media/upload", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-owner-key": ownerKey },
      body: JSON.stringify({ filename, contentType: blob.type || "image/png", base64 }),
    });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      throw new Error(data.message || "Cloud media upload failed.");
    }
    return data.uploaded as { publicUrl: string; path: string };
  }

  async function testInstagramHealth() {
    if (!ownerKey) {
      setStatus("Login first, then test Instagram connection.");
      return;
    }
    setStatus("Checking Instagram API connection...");
    try {
      const res = await fetch("/api/instagram/health", {
        method: "GET",
        headers: { "x-owner-key": ownerKey },
        cache: "no-store",
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setStatus(`Instagram health failed: ${JSON.stringify(data.result || data.message || data).slice(0, 320)}. Use /api/instagram/diagnose after login owner key if needed.`);
        return;
      }
      const profile = data.profile?.username ? ` Connected as @${data.profile.username}.` : " Credentials found.";
      setStatus(`Instagram health ok.${profile} You can now test Auto Publish Feed.`);
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Instagram health check failed.");
    }
  }

  async function publishFeedToInstagram() {
    if (!pack) return;
    try {
      setStatus("Uploading Instagram-safe JPG to Supabase Storage...");
      const blob = await jpgFromCard(
        pack.feedCard.headline,
        pack.feedCard.subline,
        pack.feedCard.footer,
        "feed",
        pack.palette,
      );
      const uploaded = await uploadBlobToCloud(`${pack.isoDate}/feed-${pack.isoDate}.jpg`, blob);
      setStatus("Publishing feed post to Instagram...");
      const res = await fetch("/api/instagram/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-owner-key": ownerKey },
        body: JSON.stringify({
          imageUrl: uploaded.publicUrl,
          caption: `${pack.caption}\n\n${hashtags}`,
          kind: "feed",
        }),
      });
      const data = await res.json();
      setStatus(data.ok ? "Feed post published to Instagram." : `Instagram feed failed: ${JSON.stringify(data.result || data.message || data).slice(0, 260)}`);
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Instagram feed publish failed.");
    }
  }

  async function publishStoriesToInstagram() {
    if (!pack) return;
    try {
      for (const story of pack.stories) {
        setStatus(`Uploading ${story.slot} story to Supabase Storage...`);
        const blob = await jpgFromCard(story.title, story.subtitle, story.cta, "story", pack.palette);
        const uploaded = await uploadBlobToCloud(`${pack.isoDate}/story-${story.slot}-${pack.isoDate}.jpg`, blob);
        setStatus(`Publishing ${story.slot} story to Instagram...`);
        const res = await fetch("/api/instagram/publish", {
          method: "POST",
          headers: { "Content-Type": "application/json", "x-owner-key": ownerKey },
          body: JSON.stringify({ imageUrl: uploaded.publicUrl, kind: "story" }),
        });
        const data = await res.json();
        if (!data.ok) {
          setStatus(`Story failed at ${story.slot}: ${JSON.stringify(data.result || data.message || data).slice(0, 260)}`);
          return;
        }
      }
      setStatus("All stories published to Instagram.");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Instagram story publish failed.");
    }
  }

  async function runServerAutopilot() {
    if (!ownerKey) {
      setStatus("Paste your Cloud password / OWNER_SECRET first, then run autopilot.");
      return;
    }
    try {
      setStatus("Running full autopilot: generate → upload → publish → WhatsApp report...");
      const res = await fetch("/api/autopilot/run", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-owner-key": ownerKey },
        body: JSON.stringify({
          niche,
          intensity,
          accountGoal,
          publishFeed: true,
          publishStories: true,
          sendWhatsApp: true,
        }),
      });
      const data = await res.json();
      setStatus(data.ok ? "Full autopilot completed. Check Instagram and WhatsApp." : `Autopilot failed: ${JSON.stringify(data).slice(0, 300)}`);
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Autopilot failed.");
    }
  }

  if (!hydrationReady) {
    return (
      <main className="shell login-shell" suppressHydrationWarning>
        <section className="login-card card">
          <span className="brand-pill">
            <Sparkles size={16} /> officialwhokeas Ai • loading secure access
          </span>
          <h1>officialwhokeas Ai</h1>
          <p>Loading secure session. This prevents browser/PWA cache mismatch.</p>
        </section>
      </main>
    );
  }

  if (!isUnlocked) {
    return (
      <main className="shell login-shell" suppressHydrationWarning>
        <section className="login-card card">
          <span className="brand-pill">
            <Sparkles size={16} /> officialwhokeas Ai • stable login v20
          </span>
          <h1>officialwhokeas Ai</h1>
          <p>
            Login to open the content engine, PWA installer, cloud memory, WhatsApp reports, and Instagram auto-posting.
          </p>
          <label className="login-label">
            System password
            <input
              value={ownerKey}
              onChange={(e) => setOwnerKey(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") loginToSystem();
              }}
              placeholder="Enter OWNER_SECRET"
              type="password"
              autoComplete="current-password"
              autoFocus
            />
          </label>
          <div className="actions">
            <button className="btn" onClick={loginToSystem} disabled={authLoading}>
              <Sparkles size={16} /> {authLoading ? "Checking..." : "Login"}
            </button>
            <button className="btn secondary" onClick={installApp}>
              <Smartphone size={16} /> Install App
            </button>
          </div>
          {loginStatus && <div className="status">{loginStatus}</div>}
          <div className="login-notes">
            <span>Downloadable PWA</span>
            <span>Owner-only access</span>
            <span>Instagram automation ready</span>
          </div>
        </section>
      </main>
    );
  }

  return (
    <main className="shell" suppressHydrationWarning>
      <section className="hero">
        <div className="card">
          <span className="brand-pill">
            <Sparkles size={16} /> officialwhokeas Ai • visual text fix v26
          </span>
          <h1>officialwhokeas Ai</h1>
          <p>
            A modern-classic content desk with local + Supabase memory. It remembers old plans,
            protects against repeated topics, adjusts hooks by goal, and prepares the system
            for Vercel deployment, cloud backup, Instagram publishing, WhatsApp reporting, and autopilot runs.
          </p>
          <div className="control-row">
            <label>
              Content mode
              <select value={niche} onChange={(e) => setNiche(e.target.value)}>
                {nicheOptions.map((item) => (
                  <option key={item.value} value={item.value}>
                    {item.label}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Content intensity
              <select
                value={intensity}
                onChange={(e) => setIntensity(e.target.value as ContentIntensity)}
              >
                {intensityOptions.map((item) => (
                  <option key={item.value} value={item.value}>
                    {item.label}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Account goal
              <select
                value={accountGoal}
                onChange={(e) => setAccountGoal(e.target.value as AccountGoal)}
              >
                {goalOptions.map((item) => (
                  <option key={item.value} value={item.value}>
                    {item.label}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <div className="actions">
            <button
              className="btn"
              onClick={() => generate(1)}
              disabled={loading}
            >
              <Wand2 size={16} /> {loading ? "Generating..." : "Generate Today"}
            </button>
            <button
              className="btn"
              onClick={() => generate(7)}
              disabled={loading}
            >
              <CalendarClock size={16} /> Generate 7 Days
            </button>
            <button
              className="btn"
              onClick={() => generate(14)}
              disabled={loading}
            >
              <CalendarClock size={16} /> Generate 14 Days
            </button>
            <button
              className="btn secondary"
              onClick={downloadTodayZip}
              disabled={!pack}
            >
              <Archive size={16} /> Today ZIP
            </button>
            <button
              className="btn secondary"
              onClick={downloadWeekZip}
              disabled={!week.length}
            >
              <Download size={16} /> Plan ZIP
            </button>
            <button
              className="btn secondary"
              onClick={installApp}
            >
              <Smartphone size={16} /> Install App
            </button>
            <button
              className="btn secondary"
              onClick={sendWhatsAppReport}
              disabled={!pack}
            >
              <MessageCircle size={16} /> WhatsApp Report
            </button>
            <button
              className="btn secondary"
              onClick={publishFeedToInstagram}
              disabled={!pack || !ownerKey}
            >
              <Camera size={16} /> Auto Publish Feed
            </button>
            <button
              className="btn secondary"
              onClick={publishStoriesToInstagram}
              disabled={!pack || !ownerKey}
            >
              <Camera size={16} /> Auto Publish Stories
            </button>
            <button
              className="btn secondary"
              onClick={testInstagramHealth}
              disabled={!ownerKey}
            >
              <Camera size={16} /> Instagram Health
            </button>
            <button
              className="btn"
              onClick={runServerAutopilot}
              disabled={!ownerKey}
            >
              <Sparkles size={16} /> Full Autopilot
            </button>
            <button className="btn secondary" onClick={logoutFromSystem}>
              Logout
            </button>
          </div>
          {status && <div className="status">{status}</div>}
          <div className="cloud-control-panel">
            <div>
              <strong>Cloud password</strong>
              <p>Paste the same value you used in Vercel as OWNER_SECRET. This unlocks Cloud Save and Cloud Load.</p>
            </div>
            <input
              value={ownerKey}
              onChange={(e) => setOwnerKey(e.target.value)}
              placeholder="Paste OWNER_SECRET here"
              type="password"
              autoComplete="current-password"
            />
            <button className="btn" onClick={saveCloudMemory} disabled={cloudLoading || !ownerKey}>
              Cloud Save
            </button>
            <button className="btn secondary" onClick={loadCloudMemory} disabled={cloudLoading || !ownerKey}>
              Cloud Load
            </button>
            <button className="btn secondary" onClick={testCloudHealth}>
              Cloud Health
            </button>
          </div>
          <div className="badges">
            <span className="badge">Modern classic UI</span>
            <span className="badge">Local + Supabase memory</span>
            <span className="badge">Used-topic protection</span>
            <span className="badge">Content vault</span>
            <span className="badge">Downloadable PNG/ZIP</span>
            <span className="badge">PWA offline shell</span>
            <span className="badge">Signature posting system</span>
            <span className="badge">Instagram + WhatsApp automation</span>
          </div>
        </div>
        <div className="card">
          <h2>
            <CalendarClock size={20} /> Brain + Memory
          </h2>
          <div className="app-stat-row">
            <span><b>{vault.length}</b><em>saved packs</em></span>
            <span><b>{usedTopicCount}</b><em>protected topics</em></span>
            <span><b>{bestPack ? scorePack(bestPack) : 0}</b><em>best score</em></span>
          </div>
          <label className="cloud-key-label">
            Owner key for cloud save/load
            <input
              value={ownerKey}
              onChange={(e) => setOwnerKey(e.target.value)}
              placeholder="Enter your OWNER_SECRET"
              type="password"
            />
          </label>
          <ul className="list compact-list">
            <li>Goal now: {goalOptions.find((g) => g.value === accountGoal)?.label}</li>
            <li>Intensity now: {intensityOptions.find((i) => i.value === intensity)?.label}</li>
            <li>Best current idea: {bestPack?.mainTopic || "Generate a plan first"}</li>
            <li>Repeats avoided from vault + current week.</li>
          </ul>
          <div className="actions">
            <button className="btn secondary" onClick={copyMemorySummary}>
              <Copy size={16} /> Copy Memory
            </button>
            <button className="btn secondary" onClick={downloadMemoryJson}>
              <Download size={16} /> Backup Memory
            </button>
            <button className="btn" onClick={saveCloudMemory} disabled={cloudLoading || !ownerKey}>
              Cloud Save
            </button>
            <button className="btn secondary" onClick={loadCloudMemory} disabled={cloudLoading || !ownerKey}>
              Cloud Load
            </button>
            <button className="btn secondary" onClick={testCloudHealth}>
              Cloud Health
            </button>
            <button className="btn secondary" onClick={clearVault}>
              Clear Vault
            </button>
          </div>
        </div>
      </section>

      {vault.length > 0 && (
        <section className="card calendar-card">
          <div className="section-head">
            <div>
              <h2>Content Vault</h2>
              <p className="small">
                Local memory keeps generated topics in this browser. Supabase cloud memory backs it up online so Vercel and future devices can load the same brain.
              </p>
            </div>
            <span className="pill good">{vault.length} saved items</span>
          </div>
          <div className="memory-grid">
            {vault.slice(0, 8).map((item) => (
              <button
                key={item.id}
                className="memory-item"
                onClick={() => setPack(item.pack)}
              >
                <strong>{item.pack.mainTopic}</strong>
                <span>{item.pack.date} • {item.intensity} • {item.accountGoal}</span>
                <em>{item.pack.growthScore.stopPower} stop power</em>
              </button>
            ))}
          </div>
        </section>
      )}

      {week.length > 0 && (
        <section className="card calendar-card">
          <div className="section-head">
            <div>
              <h2>Post Calendar + Progress</h2>
              <p className="small">
                Click a day, download its post pack, then mark the tasks as
                posted.
              </p>
            </div>
            <button className="btn secondary" onClick={resetAllPosted}>
              Reset All Posted Marks
            </button>
          </div>
          <div className="calendar-grid">
            {week.map((item) => {
              const p = progressFor(item, posted);
              return (
                <button
                  key={item.isoDate}
                  className={`calendar-item ${pack?.isoDate === item.isoDate ? "active" : ""} ${p.done === p.total ? "done" : ""}`}
                  onClick={() => setPack(item)}
                >
                  <strong>{item.dayLabel}</strong>
                  <span>{item.date}</span>
                  <em>{item.mainTopic}</em>
                  <div className="mini-progress">
                    <i style={{ width: `${p.percent}%` }} />
                  </div>
                  <span>
                    {p.done}/{p.total} posted
                  </span>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {pack && (
        <section className="grid">
          <div className="card col-12">
            <div className="section-head">
              <div>
                <h2>Today’s Posting Checklist — {pack.date}</h2>
                <p className="small">
                  Progress: {currentProgress.done}/{currentProgress.total}{" "}
                  posted. Main topic: <strong>{pack.mainTopic}</strong>
                </p>
              </div>
              <div className="actions inline-actions">
                <button className="btn" onClick={copyChecklist}>
                  <Copy size={16} /> Copy Checklist
                </button>
                <button className="btn secondary" onClick={markSelectedDayDone}>
                  Mark Day Done
                </button>
                <button className="btn secondary" onClick={resetSelectedDay}>
                  Reset Day
                </button>
              </div>
            </div>
            <div className="task-grid">
              {pack.postingPlan.map((item) => {
                const key = scheduleKey(item.label);
                const checked = Boolean(posted[pack.isoDate]?.[key]);
                return (
                  <label
                    key={`${item.time}-${item.label}`}
                    className={`task-item ${checked ? "checked" : ""}`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => togglePosted(pack.isoDate, key)}
                    />
                    <span className="task-time">{item.time}</span>
                    <span className="task-main">
                      <strong>{item.label}</strong>
                      <em>{item.task}</em>
                    </span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="card col-4">
            <h2>Feed Card</h2>
            <div className={`feed-preview ${pack.palette}`}>
              <div className="preview-label">quiet truth</div>
              <div className="preview-title">{pack.feedCard.headline}</div>
              <div className="preview-text">
                {pack.feedCard.subline}
                <br />
                {pack.feedCard.footer}
              </div>
            </div>
            <div className="actions">
              <button className="btn" onClick={downloadFeedPng}>
                <Download size={16} /> Download PNG
              </button>
              <button className="btn secondary" onClick={downloadFeedSvg}>
                <Download size={16} /> SVG
              </button>
              <button
                className="btn secondary"
                onClick={() => togglePosted(pack.isoDate, "feed")}
              >
                {posted[pack.isoDate]?.feed
                  ? "Unmark Feed"
                  : "Mark Feed Posted"}
              </button>
            </div>
          </div>

          <div className="card col-8">
            <h2>Today’s Stories</h2>
            <div className="preview-grid">
              {pack.stories.map((story, index) => (
                <div key={story.slot}>
                  <div className={`story ${pack.palette}`}>
                    <div className="preview-label">
                      {story.slot.toUpperCase()}
                    </div>
                    <div className="preview-title">{story.title}</div>
                    <div className="preview-text">
                      {story.subtitle}
                      <br />
                      {story.cta}
                    </div>
                  </div>
                  <div className="actions">
                    <button
                      className="btn"
                      onClick={() => downloadStoryPng(index)}
                    >
                      <Download size={16} /> PNG
                    </button>
                    <button
                      className="btn secondary"
                      onClick={() => downloadStorySvg(index)}
                    >
                      <Download size={16} /> SVG
                    </button>
                    <button
                      className="btn secondary"
                      onClick={() => togglePosted(pack.isoDate, story.slot)}
                    >
                      {posted[pack.isoDate]?.[story.slot] ? "Unmark" : "Posted"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="card col-6">
            <h2>Caption + Hashtags</h2>
            <textarea readOnly value={`${pack.caption}\n\n${hashtags}`} />
            <div className="actions">
              <button className="btn" onClick={copyCaption}>
                <Copy size={16} /> Copy Caption
              </button>
              <button
                className="btn secondary"
                onClick={() =>
                  downloadText(
                    `caption-${pack.isoDate}.txt`,
                    `${pack.caption}\n\n${hashtags}`,
                  )
                }
              >
                <Download size={16} /> TXT
              </button>
              <span
                className={`pill ${posted[pack.isoDate]?.caption ? "good" : ""}`}
              >
                {posted[pack.isoDate]?.caption
                  ? "Caption copied"
                  : "Caption not copied"}
              </span>
            </div>
          </div>

          <div className="card col-6">
            <h2>Growth Score</h2>
            <ul className="list compact-list">
              <li>
                <strong>Stop power:</strong> {pack.growthScore.stopPower}
              </li>
              <li>
                <strong>Why people save:</strong> {pack.growthScore.saveReason}
              </li>
              <li>
                <strong>Comment trigger:</strong>{" "}
                {pack.growthScore.commentTrigger}
              </li>
              <li>
                <strong>Safety:</strong> {pack.growthScore.safetyRule}
              </li>
            </ul>
          </div>

          <div className="card col-6 signature-card">
            <h2>Signature Posting System</h2>
            <p className="small">
              This is the recognition layer: the same visual rhythm and story rhythm make followers identify your page quickly without needing your face.
            </p>
            <ul className="list compact-list">
              <li><strong>Format:</strong> {pack.recognitionSystem?.formatName}</li>
              <li><strong>Visual fingerprint:</strong> {pack.recognitionSystem?.visualFingerprint}</li>
              <li><strong>First line:</strong> {pack.recognitionSystem?.firstLineRule}</li>
              <li><strong>Caption move:</strong> {pack.recognitionSystem?.captionMove}</li>
              <li><strong>Story rhythm:</strong> {pack.recognitionSystem?.storySequence}</li>
              <li><strong>Follower action:</strong> {pack.recognitionSystem?.followerAction}</li>
            </ul>
            <div className="actions">
              <button className="btn secondary" onClick={copySignatureGuide}>
                <Copy size={16} /> Copy Signature Guide
              </button>
            </div>
          </div>

          <div className="card col-6">
            <h2>Reel Script</h2>
            <ul className="list">
              {pack.reelScript.map((line) => (
                <li key={line}>{line}</li>
              ))}
            </ul>
          </div>

          <div className="card col-6">
            <h2>Carousel Copy</h2>
            <ul className="list">
              {pack.carousel.map((line) => (
                <li key={line}>{line}</li>
              ))}
            </ul>
          </div>

          <div className="card col-12">
            <h2>WhatsApp Report</h2>
            <textarea readOnly value={pack.whatsappReport} />
            <div className="actions">
              <button className="btn" onClick={sendWhatsAppReport} disabled={!ownerKey}>
                <MessageCircle size={16} /> Send/Open Report
              </button>
              <button
                className="btn secondary"
                onClick={() =>
                  downloadText(
                    `report-${pack.isoDate}.txt`,
                    pack.whatsappReport,
                  )
                }
              >
                <Download size={16} /> TXT
              </button>
            </div>
            {!ownerKey && (
              <div className="status warning">Paste your Cloud password / OWNER_SECRET near the top before sending WhatsApp automatically.</div>
            )}
            {status && <div className="status">{status}</div>}
          </div>
        </section>
      )}

      <p className="footer">
        officialwhokeas Ai v26 — browser-canvas text rendering fix + downloadable PWA + Instagram/WhatsApp automation.
      </p>
    </main>
  );
}
