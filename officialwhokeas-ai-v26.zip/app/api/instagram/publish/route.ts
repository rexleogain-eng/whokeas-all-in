import { NextResponse } from "next/server";
import { publishInstagramImage, requireOwner } from "@/lib/server/automation";

export const dynamic = "force-dynamic";

type Body = {
  imageUrl?: string;
  caption?: string;
  kind?: "feed" | "story";
};

export async function POST(request: Request) {
  const auth = requireOwner(request);
  if (!auth.ok) return NextResponse.json({ ok: false, message: auth.message }, { status: auth.status });

  const body = (await request.json()) as Body;
  if (!body.imageUrl) {
    return NextResponse.json(
      { ok: false, message: "imageUrl is required and must be publicly accessible." },
      { status: 400 },
    );
  }

  const result = await publishInstagramImage({
    imageUrl: body.imageUrl,
    caption: body.caption || "",
    kind: body.kind || "feed",
  });

  return NextResponse.json(result, { status: result.ok || result.mode === "demo" ? 200 : 400 });
}
