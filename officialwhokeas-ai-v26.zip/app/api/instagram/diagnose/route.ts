import { NextResponse } from "next/server";
import { env, envAny, getInstagramConfig, requireOwner } from "@/lib/server/automation";

export const dynamic = "force-dynamic";

async function safeJson(url: string) {
  const res = await fetch(url, { cache: "no-store" });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

export async function GET(request: Request) {
  const auth = requireOwner(request);
  if (!auth.ok) return NextResponse.json({ ok: false, message: auth.message }, { status: auth.status });

  const cfg = getInstagramConfig();
  const maskedToken = cfg.accessToken ? `${cfg.accessToken.slice(0, 8)}...${cfg.accessToken.slice(-6)}` : "missing";

  const report: Record<string, unknown> = {
    ok: true,
    mode: cfg.mode,
    modeRaw: cfg.modeRaw,
    tokenPreview: maskedToken,
    tokenPrefix: cfg.accessToken ? cfg.accessToken.slice(0, 4) : "missing",
    tokenLength: cfg.accessToken.length,
    igUserId: cfg.igUserId || "missing",
    graphBase: cfg.graphBase,
    checks: [],
    recommendedFix: [],
  };

  const checks: unknown[] = [];
  const recommendedFix: string[] = [];

  if (!cfg.accessToken) recommendedFix.push("Add INSTAGRAM_ACCESS_TOKEN to Vercel/local env.");
  if (!cfg.igUserId) recommendedFix.push("Add INSTAGRAM_IG_USER_ID. This must be the numeric IG user ID, not username.");

  if (cfg.accessToken) {
    const me = await safeJson(`${cfg.graphBase}/me?fields=id,name,username&access_token=${encodeURIComponent(cfg.accessToken)}`);
    checks.push({ name: "token_me", ...me });

    if (/^IG/i.test(cfg.accessToken) && cfg.mode !== "instagram_login") {
      recommendedFix.push("Token starts with IG but mode is not instagram_login. Set INSTAGRAM_API_MODE=instagram_login or use v21 auto-detect.");
    }
    if (/^EA/i.test(cfg.accessToken) && cfg.mode !== "facebook_login") {
      recommendedFix.push("Token starts with EA but mode is instagram_login. Use Facebook/Page mode or generate an Instagram Login token.");
    }

    if (cfg.mode === "facebook_login") {
      const pages = await safeJson(`https://graph.facebook.com/${cfg.graphVersion}/me/accounts?fields=id,name,access_token,instagram_business_account&access_token=${encodeURIComponent(cfg.accessToken)}`);
      checks.push({ name: "facebook_pages_me_accounts", ...pages });
      const data = Array.isArray((pages.json as any)?.data) ? (pages.json as any).data : [];
      if (pages.ok && data.length === 0) {
        recommendedFix.push("/me/accounts returned empty. Reconnect Instagram Professional account to a Facebook Page and make sure your Facebook profile has full Page access, or switch to INSTAGRAM_API_MODE=instagram_login.");
      }
    }
  }

  if (cfg.accessToken && cfg.igUserId) {
    const profileUrl = cfg.mode === "instagram_login"
      ? `${cfg.graphBase}/me?fields=${encodeURIComponent("user_id,username")}&access_token=${encodeURIComponent(cfg.accessToken)}`
      : `${cfg.graphBase}/${encodeURIComponent(cfg.igUserId)}?fields=id,username&access_token=${encodeURIComponent(cfg.accessToken)}`;
    const profile = await safeJson(profileUrl);
    checks.push({ name: cfg.mode === "instagram_login" ? "ig_login_me" : "ig_profile", ...profile });
    if (!profile.ok) recommendedFix.push("IG profile test failed. For Instagram Login tokens, regenerate the IGAA token from Instagram API setup and save it on one line.");
  }

  report.checks = checks;
  report.recommendedFix = recommendedFix;
  return NextResponse.json(report);
}
