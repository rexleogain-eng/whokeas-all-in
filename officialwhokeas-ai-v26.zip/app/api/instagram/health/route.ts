import { NextResponse } from "next/server";
import { env, envAny, getInstagramConfig, requireOwner } from "@/lib/server/automation";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const auth = requireOwner(request);
  if (!auth.ok) {
    return NextResponse.json(
      { ok: false, message: auth.message },
      { status: auth.status },
    );
  }

  const cfg = getInstagramConfig();
  const supabaseUrl = envAny(["SUPABASE_URL", "NEXT_PUBLIC_SUPABASE_URL"]);
  const serviceKey = env("SUPABASE_SERVICE_ROLE_KEY");
  const bucket = env("SUPABASE_STORAGE_BUCKET") || "owai-generated";

  const envStatus = {
    INSTAGRAM_API_MODE: cfg.mode,
    INSTAGRAM_API_MODE_RAW: cfg.modeRaw,
    INSTAGRAM_ACCESS_TOKEN: Boolean(cfg.accessToken),
    tokenPrefix: cfg.accessToken ? cfg.accessToken.slice(0, 4) : "missing",
    tokenLength: cfg.accessToken.length,
    INSTAGRAM_IG_USER_ID: Boolean(cfg.igUserId),
    igUserId: cfg.igUserId || "missing",
    META_GRAPH_VERSION: cfg.graphVersion,
    graphBase: cfg.graphBase,
    SUPABASE_URL: Boolean(supabaseUrl),
    SUPABASE_SERVICE_ROLE_KEY: Boolean(serviceKey),
    SUPABASE_STORAGE_BUCKET: bucket,
  };

  if (!cfg.accessToken || !cfg.igUserId) {
    return NextResponse.json(
      {
        ok: false,
        message:
          "Instagram credentials missing. Add INSTAGRAM_ACCESS_TOKEN and INSTAGRAM_IG_USER_ID. If /me/accounts returns [], use Instagram Login mode or reconnect IG to a Facebook Page.",
        env: envStatus,
      },
      { status: 400 },
    );
  }

  // v25: Instagram Login tokens are most reliably verified through /me.
  // Publishing still uses /{IG_USER_ID}/media, but health should prove the token itself first.
  const url = cfg.mode === "instagram_login"
    ? `${cfg.graphBase}/me?fields=${encodeURIComponent("user_id,username")}&access_token=${encodeURIComponent(cfg.accessToken)}`
    : `${cfg.graphBase}/${encodeURIComponent(cfg.igUserId)}?fields=${encodeURIComponent("id,username")}&access_token=${encodeURIComponent(cfg.accessToken)}`;

  const res = await fetch(url, { cache: "no-store" });
  const result = await res.json().catch(() => ({}));

  if (!res.ok) {
    return NextResponse.json(
      {
        ok: false,
        message:
          "Instagram token or IG user ID failed. Confirm the token belongs to the same API mode and account as INSTAGRAM_IG_USER_ID.",
        env: envStatus,
        result,
        fix: [
          "If token starts IGAA/IGQV, use INSTAGRAM_API_MODE=instagram_login and graph.instagram.com. v21 auto-detects this.",
          "If token starts EAAG/EAA, use Facebook/Page mode with a Page access token and IG ID from instagram_business_account.id.",
          "If tokenLength is very short, your .env.local may have truncated the token. Put the token on one line; if it contains #, wrap it in double quotes locally.",
          "Do not include Bearer, access_token=, quotes in Vercel, or spaces/new lines.",
        ],
      },
      { status: 400 },
    );
  }

  return NextResponse.json({
    ok: true,
    env: envStatus,
    profile: result,
    message: cfg.mode === "instagram_login"
      ? `Instagram health ok. Connected as @${result.username || "unknown"}. user_id=${result.user_id || "unknown"}`
      : `Instagram health ok. Connected as @${result.username || "unknown"}.`,
  });
}
