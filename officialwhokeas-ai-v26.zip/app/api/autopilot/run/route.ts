import { NextRequest, NextResponse } from "next/server";
import { AccountGoal, ContentIntensity, generateSmartPlan } from "@/lib/content";
import {
  publishInstagramImage,
  requireOwner,
  sendWhatsAppText,
  uploadPackCard,
} from "@/lib/server/automation";

export const dynamic = "force-dynamic";

const allowedIntensity: ContentIntensity[] = ["normal", "crazy", "deep", "money", "study", "trading"];
const allowedGoals: AccountGoal[] = ["followers", "saves", "comments", "dms", "traffic"];

function safeIntensity(value: string | null): ContentIntensity {
  return allowedIntensity.includes(value as ContentIntensity) ? (value as ContentIntensity) : "deep";
}

function safeGoal(value: string | null): AccountGoal {
  return allowedGoals.includes(value as AccountGoal) ? (value as AccountGoal) : "saves";
}

async function run(request: NextRequest) {
  const auth = requireOwner(request);
  if (!auth.ok) return NextResponse.json({ ok: false, message: auth.message }, { status: auth.status });

  const { searchParams } = new URL(request.url);
  let body: any = {};
  if (request.method === "POST") {
    try { body = await request.json(); } catch { body = {}; }
  }

  const niche = body.niche || searchParams.get("niche") || process.env.NEXT_PUBLIC_NICHE || "psychomix";
  const intensity = safeIntensity(body.intensity || searchParams.get("intensity"));
  const accountGoal = safeGoal(body.accountGoal || body.goal || searchParams.get("goal"));
  const publishFeed = body.publishFeed ?? searchParams.get("feed") !== "0";
  const publishStories = body.publishStories ?? searchParams.get("stories") !== "0";
  const sendWhatsApp = body.sendWhatsApp ?? searchParams.get("whatsapp") !== "0";

  const pack = generateSmartPlan(niche, 1, { intensity, accountGoal })[0];
  const results: Record<string, unknown> = { pack };

  if (publishFeed) {
    const uploaded = await uploadPackCard(pack, "feed");
    const publish = await publishInstagramImage({
      imageUrl: uploaded.publicUrl,
      caption: pack.caption,
      kind: "feed",
    });
    results.feed = { uploaded, publish };
  }

  if (publishStories) {
    const storyResults = [];
    for (let i = 0; i < pack.stories.length; i++) {
      const uploaded = await uploadPackCard(pack, "story", i);
      const publish = await publishInstagramImage({
        imageUrl: uploaded.publicUrl,
        kind: "story",
      });
      storyResults.push({ slot: pack.stories[i].slot, uploaded, publish });
    }
    results.stories = storyResults;
  }

  if (sendWhatsApp) {
    results.whatsapp = await sendWhatsAppText(pack.whatsappReport);
  }

  return NextResponse.json({ ok: true, results });
}

export async function GET(request: NextRequest) {
  return run(request);
}

export async function POST(request: NextRequest) {
  return run(request);
}
