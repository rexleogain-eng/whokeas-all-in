import { NextRequest, NextResponse } from "next/server";
import {
  AccountGoal,
  ContentIntensity,
  generateSmartPlan,
} from "@/lib/content";

const allowedIntensity: ContentIntensity[] = [
  "normal",
  "crazy",
  "deep",
  "money",
  "study",
  "trading",
];

const allowedGoals: AccountGoal[] = [
  "followers",
  "saves",
  "comments",
  "dms",
  "traffic",
];

function safeIntensity(value: string | null): ContentIntensity {
  return allowedIntensity.includes(value as ContentIntensity)
    ? (value as ContentIntensity)
    : "deep";
}

function safeGoal(value: string | null): AccountGoal {
  return allowedGoals.includes(value as AccountGoal)
    ? (value as AccountGoal)
    : "saves";
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const niche = searchParams.get("niche") || process.env.NEXT_PUBLIC_NICHE || "psychomix";
  const days = Math.min(Number(searchParams.get("days") || "1"), 14);
  const intensity = safeIntensity(searchParams.get("intensity"));
  const accountGoal = safeGoal(searchParams.get("goal"));
  const avoidTopics = (searchParams.get("avoid") || "")
    .split("|")
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 60);

  const packs = generateSmartPlan(niche, Math.max(days, 1), {
    intensity,
    accountGoal,
    avoidTopics,
  });

  if (days > 1) {
    return NextResponse.json({ packs });
  }

  return NextResponse.json(packs[0]);
}
