import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

function env(name: string) {
  return process.env[name]?.trim() || "";
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const mode = url.searchParams.get("hub.mode");
  const token = url.searchParams.get("hub.verify_token");
  const challenge = url.searchParams.get("hub.challenge");
  const expected = env("WHATSAPP_VERIFY_TOKEN") || env("META_WEBHOOK_VERIFY_TOKEN");

  if (!expected) {
    return NextResponse.json(
      { ok: false, message: "WHATSAPP_VERIFY_TOKEN is missing in environment variables." },
      { status: 500 }
    );
  }

  if (mode === "subscribe" && token === expected && challenge) {
    return new Response(challenge, {
      status: 200,
      headers: { "Content-Type": "text/plain" },
    });
  }

  return NextResponse.json(
    { ok: false, message: "Webhook verification failed. Check callback URL and verify token." },
    { status: 403 }
  );
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    console.log("officialwhokeas Ai WhatsApp webhook event", JSON.stringify(body).slice(0, 4000));
    return NextResponse.json({ ok: true, received: true });
  } catch {
    return NextResponse.json({ ok: true, received: true, message: "No JSON body." });
  }
}
