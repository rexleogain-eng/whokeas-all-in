import { NextResponse } from "next/server";
import { requireOwner, sendWhatsAppText } from "@/lib/server/automation";

export const dynamic = "force-dynamic";

type Body = {
  report?: string;
  posts?: string;
  stories?: string;
  angle?: string;
  action?: string;
};

export async function POST(request: Request) {
  const auth = requireOwner(request);
  if (!auth.ok) return NextResponse.json({ ok: false, message: auth.message }, { status: auth.status });

  const body = (await request.json()) as Body;
  const report = body.report || "officialwhokeas Ai daily content report generated.";
  const result = await sendWhatsAppText(report, {
    posts: body.posts || "1 feed post",
    stories: body.stories || "4 story posts",
    angle: body.angle || "Psychology Growth Engine",
    action: body.action || "Post today's feed card and stories",
  });
  return NextResponse.json(result, { status: result.ok || result.mode === "manual-free" ? 200 : 400 });
}
