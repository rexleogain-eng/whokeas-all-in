import { NextResponse } from "next/server";
import { requireOwner } from "@/lib/server/automation";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const auth = requireOwner(request);
  if (!auth.ok) {
    return NextResponse.json(
      { ok: false, message: auth.message },
      { status: auth.status },
    );
  }

  return NextResponse.json({ ok: true, message: "Access granted." });
}
