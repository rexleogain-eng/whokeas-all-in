import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type SnapshotPayload = {
  vault?: unknown;
  posted?: unknown;
  settings?: unknown;
  week?: unknown;
  currentPack?: unknown;
  savedFrom?: string;
};

function env(name: string) {
  return process.env[name]?.trim() || "";
}

function unauthorized(message = "Cloud memory is locked. Check your owner key.") {
  return NextResponse.json({ ok: false, message }, { status: 401 });
}

export async function POST(req: Request) {
  const ownerSecret = env("OWNER_SECRET");
  const suppliedKey = req.headers.get("x-owner-key")?.trim() || "";

  if (!ownerSecret) {
    return NextResponse.json(
      { ok: false, message: "OWNER_SECRET is missing in environment variables." },
      { status: 500 },
    );
  }

  if (suppliedKey !== ownerSecret) return unauthorized();

  const supabaseUrl = env("SUPABASE_URL") || env("NEXT_PUBLIC_SUPABASE_URL");
  const serviceKey = env("SUPABASE_SERVICE_ROLE_KEY");

  if (!supabaseUrl || !serviceKey) {
    return NextResponse.json(
      {
        ok: false,
        message:
          "Supabase credentials are missing. Add SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env.local / Vercel.",
      },
      { status: 500 },
    );
  }

  const payload = (await req.json()) as SnapshotPayload;

  const response = await fetch(`${supabaseUrl}/rest/v1/owai_memory_snapshots`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: serviceKey,
      Authorization: `Bearer ${serviceKey}`,
      Prefer: "return=representation",
    },
    body: JSON.stringify({
      owner_id: "officialwhokeas",
      app_version: "v13",
      payload,
    }),
    cache: "no-store",
  });

  const text = await response.text();

  if (!response.ok) {
    return NextResponse.json(
      {
        ok: false,
        message: "Supabase save failed. Check that the SQL table exists.",
        details: text,
      },
      { status: response.status },
    );
  }

  let data: unknown = null;
  try {
    data = JSON.parse(text);
  } catch {
    data = text;
  }

  return NextResponse.json({ ok: true, message: "Cloud memory saved.", data });
}
