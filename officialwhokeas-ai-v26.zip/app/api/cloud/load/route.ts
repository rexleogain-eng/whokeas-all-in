import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

function env(name: string) {
  return process.env[name]?.trim() || "";
}

function unauthorized(message = "Cloud memory is locked. Check your owner key.") {
  return NextResponse.json({ ok: false, message }, { status: 401 });
}

export async function GET(req: Request) {
  const ownerSecret = env("OWNER_SECRET");
  const suppliedKey = req.headers.get("x-owner-key")?.trim() || "";

  if (!ownerSecret) {
    return NextResponse.json(
      { ok: false, message: "OWNER_SECRET is missing in environment variables." },
      { status: 500 },
    );
  }

  if (suppliedKey !== ownerSecret) return unauthorized();

  const supabaseUrl = env("SUPABASE_URL") || env("NEXT_PUBLIC_SUPABASE_URL");
  const serviceKey = env("SUPABASE_SERVICE_ROLE_KEY");

  if (!supabaseUrl || !serviceKey) {
    return NextResponse.json(
      {
        ok: false,
        message:
          "Supabase credentials are missing. Add SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env.local / Vercel.",
      },
      { status: 500 },
    );
  }

  const url = `${supabaseUrl}/rest/v1/owai_memory_snapshots?owner_id=eq.officialwhokeas&select=*&order=created_at.desc&limit=1`;
  const response = await fetch(url, {
    method: "GET",
    headers: {
      apikey: serviceKey,
      Authorization: `Bearer ${serviceKey}`,
    },
    cache: "no-store",
  });

  const text = await response.text();

  if (!response.ok) {
    return NextResponse.json(
      {
        ok: false,
        message: "Supabase load failed. Check that the SQL table exists.",
        details: text,
      },
      { status: response.status },
    );
  }

  let data: any[] = [];
  try {
    data = JSON.parse(text);
  } catch {
    data = [];
  }

  const latest = data[0] || null;

  return NextResponse.json({
    ok: true,
    message: latest ? "Cloud memory loaded." : "No cloud memory yet.",
    snapshot: latest,
    payload: latest?.payload || null,
  });
}
