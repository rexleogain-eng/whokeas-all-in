import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

function env(name: string) {
  return process.env[name]?.trim() || "";
}

function present(name: string) {
  return Boolean(env(name));
}

export async function GET() {
  const supabaseUrl = env("SUPABASE_URL") || env("NEXT_PUBLIC_SUPABASE_URL");
  const serviceKey = env("SUPABASE_SERVICE_ROLE_KEY");
  const result: Record<string, unknown> = {
    ok: true,
    app: "officialwhokeas Ai",
    version: "v13",
    env: {
      OWNER_SECRET: present("OWNER_SECRET"),
      SUPABASE_URL: Boolean(supabaseUrl),
      SUPABASE_SERVICE_ROLE_KEY: Boolean(serviceKey),
    },
  };

  if (supabaseUrl && serviceKey) {
    try {
      const response = await fetch(`${supabaseUrl}/rest/v1/owai_memory_snapshots?select=id&limit=1`, {
        method: "GET",
        headers: {
          apikey: serviceKey,
          Authorization: `Bearer ${serviceKey}`,
        },
        cache: "no-store",
      });
      const text = await response.text();
      result.table = {
        checked: true,
        ok: response.ok,
        status: response.status,
        message: response.ok ? "owai_memory_snapshots accessible" : text.slice(0, 260),
      };
    } catch (error) {
      result.table = {
        checked: true,
        ok: false,
        message: error instanceof Error ? error.message : "Table check failed",
      };
    }
  } else {
    result.table = { checked: false, ok: false, message: "Supabase credentials missing" };
  }

  return NextResponse.json(result);
}
