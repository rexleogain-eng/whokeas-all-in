import { NextResponse } from "next/server";
import { requireOwner, uploadBufferToSupabase } from "@/lib/server/automation";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const auth = requireOwner(request);
  if (!auth.ok) return NextResponse.json({ ok: false, message: auth.message }, { status: auth.status });

  const body = await request.json();
  const filename = String(body.filename || `upload-${Date.now()}.png`).replace(/[^a-zA-Z0-9_.\-/]/g, "-");
  const contentType = String(body.contentType || "image/png");
  const base64 = String(body.base64 || "");

  if (!base64) {
    return NextResponse.json({ ok: false, message: "base64 image data is required." }, { status: 400 });
  }

  try {
    const cleanBase64 = base64.includes(",") ? base64.split(",").pop()! : base64;
    const buffer = Buffer.from(cleanBase64, "base64");
    const uploaded = await uploadBufferToSupabase(filename, buffer, contentType);
    return NextResponse.json({ ok: true, uploaded });
  } catch (error) {
    return NextResponse.json(
      { ok: false, message: error instanceof Error ? error.message : "Upload failed." },
      { status: 500 },
    );
  }
}
