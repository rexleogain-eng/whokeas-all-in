import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "officialwhokeas Ai",
    short_name: "Whokeas Ai",
    description:
      "PWA + Supabase memory faceless Instagram content desk for downloadable posts, stories, calendars, reports and signature posting systems.",
    start_url: "/",
    scope: "/",
    id: "/",
    display: "standalone",
    background_color: "#f5f2ea",
    theme_color: "#171717",
    categories: ["productivity", "social", "business"],
    icons: [
      {
        src: "/icon.svg",
        sizes: "512x512",
        type: "image/svg+xml",
        purpose: "maskable",
      },
    ],
  };
}
