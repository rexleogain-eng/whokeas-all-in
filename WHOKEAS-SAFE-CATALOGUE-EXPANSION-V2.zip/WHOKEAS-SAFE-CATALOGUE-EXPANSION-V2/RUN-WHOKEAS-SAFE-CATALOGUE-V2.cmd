@echo off
setlocal EnableExtensions
title WHOKEAS ALL IN - Safe Catalogue Expansion V2
cd /d "%~dp0"

echo.
echo ============================================================
echo  WHOKEAS SAFE CATALOGUE EXPANSION V2
echo  Node-based installer - the window will remain open
echo ============================================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js was not found in PATH.
  echo Open the project PowerShell and confirm that "node -v" works.
  echo.
  pause
  exit /b 1
)

node "%~dp0INSTALL-WHOKEAS-SAFE-CATALOGUE-V2.cjs"
set "EXITCODE=%ERRORLEVEL%"

echo.
if "%EXITCODE%"=="0" (
  echo INSTALLATION FINISHED SUCCESSFULLY.
) else (
  echo INSTALLATION FAILED WITH EXIT CODE %EXITCODE%.
  echo Read the error above. A full log was saved on your Desktop.
)
echo.
pause
exit /b %EXITCODE%
