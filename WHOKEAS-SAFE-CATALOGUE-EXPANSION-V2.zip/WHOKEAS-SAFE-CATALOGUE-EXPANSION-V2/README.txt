WHOKEAS SAFE CATALOGUE EXPANSION V2

This version does not execute the installer through PowerShell.
It uses Node.js directly, preventing the variable-expansion/parser problem
seen in the previous installer.

STEPS
1. Stop npm run dev with Ctrl+C.
2. Right-click the ZIP and choose Extract All.
3. Open the extracted WHOKEAS-SAFE-CATALOGUE-EXPANSION-V2 folder.
4. Double-click RUN-WHOKEAS-SAFE-CATALOGUE-V2.cmd.
5. Keep the window open until it reports success or a clear error.
6. A full log is saved on the Desktop.

After success:
  cd "%USERPROFILE%\Desktop\whokeas-all-in"
  npm run dev

Then open:
  http://localhost:3000/admin/catalogue
