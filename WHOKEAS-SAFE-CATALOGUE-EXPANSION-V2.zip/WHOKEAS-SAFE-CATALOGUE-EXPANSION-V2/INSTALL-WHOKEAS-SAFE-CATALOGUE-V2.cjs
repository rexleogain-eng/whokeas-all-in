const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");
const { spawnSync } = require("node:child_process");

const project = path.join(os.homedir(), "Desktop", "whokeas-all-in");
const bundleRoot = __dirname;
const patchRoot = path.join(bundleRoot, "patch");
const desktop = path.join(os.homedir(), "Desktop");
const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\..+/, "").replace("T", "-");
const backupRoot = path.join(desktop, `WHOKEAS-before-catalogue-expansion-v2-${stamp}`);
const logPath = path.join(desktop, `WHOKEAS-CATALOGUE-EXPANSION-V2-${stamp}.log`);

function log(message = "") {
  const text = String(message);
  console.log(text);
  fs.appendFileSync(logPath, text + "\r\n", "utf8");
}

function fail(message) {
  throw new Error(message);
}

function exists(target) {
  return fs.existsSync(target);
}

function ensureDir(target) {
  fs.mkdirSync(target, { recursive: true });
}

function copyFileWithParents(source, destination) {
  ensureDir(path.dirname(destination));
  fs.copyFileSync(source, destination);
}

function walkFiles(root) {
  const results = [];
  if (!exists(root)) return results;

  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    const full = path.join(root, entry.name);
    if (entry.isDirectory()) {
      results.push(...walkFiles(full));
    } else if (entry.isFile()) {
      results.push(full);
    }
  }
  return results;
}

function copyTree(sourceRoot, destinationRoot) {
  for (const source of walkFiles(sourceRoot)) {
    const relative = path.relative(sourceRoot, source);
    copyFileWithParents(source, path.join(destinationRoot, relative));
  }
}

function backupRelative(relativePath) {
  const source = path.join(project, relativePath);
  if (!exists(source) || !fs.statSync(source).isFile()) return;
  copyFileWithParents(source, path.join(backupRoot, relativePath));
}

function updateEnv(name, value) {
  const envPath = path.join(project, ".env.local");
  let content = exists(envPath) ? fs.readFileSync(envPath, "utf8") : "";
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const line = `${name}="${value}"`;
  const pattern = new RegExp(`^\\s*${escaped}\\s*=.*$`, "m");

  if (pattern.test(content)) {
    content = content.replace(pattern, line);
  } else {
    if (content && !content.endsWith("\n")) content += "\r\n";
    content += `${line}\r\n`;
  }

  fs.writeFileSync(envPath, content, "utf8");
  log(`Configured ${name}=${value}`);
}

function run(command, args, options = {}) {
  log("");
  log(`> ${command} ${args.join(" ")}`);

  const result = spawnSync(command, args, {
    cwd: project,
    shell: true,
    encoding: "utf8",
    windowsHide: false,
    maxBuffer: 100 * 1024 * 1024,
    ...options,
  });

  if (result.stdout) {
    process.stdout.write(result.stdout);
    fs.appendFileSync(logPath, result.stdout, "utf8");
  }
  if (result.stderr) {
    process.stderr.write(result.stderr);
    fs.appendFileSync(logPath, result.stderr, "utf8");
  }

  if (result.error) throw result.error;
  if (result.status !== 0) {
    fail(`${command} failed with exit code ${result.status}`);
  }

  return result;
}

function runAllowStatus(command, args) {
  const result = spawnSync(command, args, {
    cwd: project,
    shell: true,
    encoding: "utf8",
    windowsHide: false,
    maxBuffer: 50 * 1024 * 1024,
  });
  if (result.error) throw result.error;
  return result;
}

function updatePackageScripts() {
  const packagePath = path.join(project, "package.json");
  const pkg = JSON.parse(fs.readFileSync(packagePath, "utf8"));
  pkg.scripts = pkg.scripts || {};
  pkg.scripts["catalogue:expand:repair"] = "tsx src/db/repair-catalogue-expansion.ts";
  pkg.scripts["catalogue:trials:clean"] = "tsx src/db/cleanup-trial-products.ts";
  fs.writeFileSync(packagePath, JSON.stringify(pkg, null, 2) + "\n", "utf8");
  log("Updated package.json scripts.");
}

const obsoleteSeedFiles = [
  "src\\db\\force-catalog.ts",
  "src\\db\\repair-catalog.ts",
  "src\\db\\seed.ts",
  "src\\db\\seed-variants.ts",
  "connect-neon-products.ps1",
  "deep-fix-product-pages.ps1",
  "repair-product-catalog.ps1",
  "seed-catalog-through-running-app.ps1",
];

try {
  ensureDir(backupRoot);
  fs.writeFileSync(logPath, "", "utf8");

  log("============================================================");
  log(" WHOKEAS — SAFE CATALOGUE EXPANSION V2");
  log(" Node-based installer: no PowerShell script parsing");
  log("============================================================");
  log("");

  if (!exists(path.join(project, "package.json"))) {
    fail(`Project not found at ${project}`);
  }
  if (!exists(path.join(patchRoot, "src", "lib", "catalogue-expansion.ts"))) {
    fail("Patch files are missing. Extract the entire ZIP before running.");
  }

  log(`Project: ${project}`);
  log(`Backup: ${backupRoot}`);
  log(`Log: ${logPath}`);
  log("");

  log("Creating a safety backup...");
  for (const patchFile of walkFiles(patchRoot)) {
    const relative = path.relative(patchRoot, patchFile);
    backupRelative(relative);
  }
  backupRelative("package.json");
  backupRelative(".env.local");
  for (const relative of obsoleteSeedFiles) backupRelative(relative);

  log("Applying the catalogue queue, cleanup system and admin page...");
  copyTree(patchRoot, project);
  updatePackageScripts();

  // Stronger throttling guard: serialized requests and slower spacing.
  updateEnv("CJ_MIN_REQUEST_INTERVAL_MS", "2500");
  updateEnv("CJ_MAX_RETRIES", "5");
  updateEnv("CJ_DEFAULT_MARGIN_PERCENT", "30");

  log("Repairing the Neon catalogue-expansion schema...");
  run("npm", ["run", "catalogue:expand:repair"]);

  log("Removing or archiving the original design-trial products...");
  run("npm", ["run", "catalogue:trials:clean"]);

  log("Disabling obsolete seed files so trial products cannot return...");
  for (const relative of obsoleteSeedFiles) {
    const target = path.join(project, relative);
    if (exists(target)) {
      fs.rmSync(target, { force: true });
      log(`Removed obsolete seed: ${relative}`);
    }
  }

  const setupSource = path.join(bundleRoot, "WHOKEAS-AUTOMATION-SETUP.txt");
  const setupDestination = path.join(desktop, "WHOKEAS-AUTOMATION-SETUP.txt");
  if (exists(setupSource)) {
    copyFileWithParents(setupSource, setupDestination);
    log(`Copied setup guide to ${setupDestination}`);
  }

  const nextDir = path.join(project, ".next");
  if (exists(nextDir)) {
    log("Clearing stale Next.js output...");
    fs.rmSync(nextDir, { recursive: true, force: true });
  }

  log("Running the production build verification...");
  run("npm", ["run", "build"]);

  const gitDir = path.join(project, ".git");
  if (exists(gitDir)) {
    log("Publishing the verified update to GitHub...");
    run("git", ["add", "."]);

    const status = runAllowStatus("git", ["status", "--porcelain"]);
    const changed = String(status.stdout || "").trim();

    if (changed) {
      run("git", ["commit", "-m", "Add safe catalogue expansion and remove trial products"]);
    } else {
      log("No new Git commit was required.");
    }

    run("git", ["push", "origin", "main"]);
  } else {
    log("Git repository not detected. Local installation and build succeeded; push was skipped.");
  }

  log("");
  log("============================================================");
  log(" WHOKEAS SAFE CATALOGUE EXPANSION V2 INSTALLED SUCCESSFULLY");
  log("============================================================");
  log("");
  log("Completed:");
  log("- Trial products cleaned or safely archived");
  log("- CJ requests serialized and spaced by 2.5 seconds");
  log("- Automatic retry protection enabled");
  log("- Approximate 30% gross-margin policy preserved");
  log("- Production build passed");
  log("");
  log("Next:");
  log("1. Run: npm run dev");
  log("2. Open: http://localhost:3000/admin/catalogue");
  log("3. Start with a batch size of 5");
  log("");
  log(`Backup: ${backupRoot}`);
  log(`Full log: ${logPath}`);
  process.exitCode = 0;
} catch (error) {
  log("");
  log("============================================================");
  log(" INSTALLATION STOPPED — READ THE ERROR BELOW");
  log("============================================================");
  log("");
  log(error && error.stack ? error.stack : String(error));
  log("");
  log(`Backup: ${backupRoot}`);
  log(`Full log: ${logPath}`);
  process.exitCode = 1;
}
